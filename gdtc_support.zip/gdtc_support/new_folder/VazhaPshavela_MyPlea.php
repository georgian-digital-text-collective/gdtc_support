<?php
	include("../gdtc_support/common.php");
	$title = "My Plea ,  ჩემი ვედრება";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">My Plea ,  ჩემი ვედრება</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Vazha-Pshavela ,  ვაჟა-ფშაველა</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Mary Childs</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2014</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Copyright 2014 DTCG. All Rights Reserved.
								
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								
								
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>
								needs to be checked
								</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ვაჟა-ფშაველა</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Vazha-Pshavela</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1> ჩემი ვედრება</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>My Plea</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ღმერთო, მიიღე ვედრება,
					
					ეს ჩემი სათხოვარია:
					
					არ დამეკარგოს გულიდან
					
					მე შენი სახსოვარია!
					
					გულს ნუ გამიტეხ ტანჯვაში,
					
					მამყოფე შეუდრკელადა
					
					ვფხიზლობდე, მუდამ მზად ვიყო
					
					დაჩაგრულების მცველადა
					
					ბალახი ვიყო სათიბი,
					
					არა მშადიან ცელობა
					
					არ წამიხდინო, მეუფევ,
					
					ეს ჩემი წმინდა ხელობა!
					
					მაშრომე საკეთილოდა,
					
					თუნდ არ მოვიმკო ნაყოფი,
					
					შვილთ საგმოდ არ გამიხადო
					
					ჩემი მუდმივი სამყოფი.
					
					გულს ნუ გამიქრობ ლამპარსა
					
					მნათობს ტრფობისა შეშითა,
					
					ნუ მავლევ ქვეყანაზედა
					
					გაცივებულის ლეშითა, -
					
					თვალებში მადლ-დაკარგულსა,
					
					შუბლზე გაკრულის მეშითა.
					
					ნუ დაუკარგავ ჩემს სატრფოს
					
					მადლს, გულზე ცეცხლის მდებელსა,
					
					ნუ დაუძვერებ ოცნებას,
					
					შენს ხმას, სხივ-გამომღებელსა:
					
					სიცოცხლედ უღირს ბეჩავსა,
					
					ეძახის თავის მხლებელსა.
					
					გულს დარდი გამიდიადე
					
					იმ სანეტარო საგანზე,
					
					დაწერე ფიქრი, ღრმა, მწვავე
					
					ჩემის გუნების საბანზე!...
					
					გონებას ფიქრი სტანჯავდეს,
					
					გულს ცეცხლი სწვავდეს ძლიერი,
					
					მშიოდ-მწყუროდეს კეთილი,
					
					ვერ გავძღე, მოვკვდე მშიერი...
					
					ნუ დამასვენებ ნურა დროს,
					
					მამყოფე შეძრწუნებული,
					
					მხოლოდ მაშინ ვარ ბედნიერ,
					
					როცა ვარ შეწუხებული
					
					როცა გულს ცეცხლი მედება,
					
					გონება მსჯელობს საღადა, -
					
					მაშენ ვარ თავისუფალი,
					
					თავს მაშინა ვგრძნობ ლაღადა.
					
					მფარავდეს შენი მარჯვენა,
					
					კალთა სამოსლის შენისა,
					
					სანამ არ მოვა დრო-ჟამი
					
					სულ ბოლოს ამოქშენისა.
					
					სული - შენი, ლეში - მიწასა, -
					
					აღარა ვგლოვობ ამასა
					
					თევზი - წყალს, ცასა - ვარსკვლავი,
					
					შვილი - დედას და მამასა.
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Oh Lord, hear my plea,
					
					This is my request: 
					
					Do not let me lose from my heart
					
					My memory of you!
					
					Do not break my heart in suffering,
					
					Let me live, unflinching, constantly ready,
					
					A defender of the oppressed.
					
					Let me be like grass to be mown,
					
					I don't care to be the scythe;
					
					Let me be just like a sheep,
					
					Let being a wolf pass me by;
					
					Do not ruin me, oh Lord,
					
					This is my sacred calling!
					
					Make me work for kind deeds,
					
					Even if I do not garner fruit,
					
					Let my children not curse
					
					My eternal resting place.
					
					Do not extinguish the lamp of my heart,
					
					It kindles my heart with love,
					
					Let me not walk this earth
					
					Like a chilled corpse, - 
					
					Let the goodness of my eyes not be lost,
					
					On my brow, crumpled like a tanned hide.
					
					Let not my beloved lose her blessedness,
					
					She who calls forth fire in my heart,
					
					Do not make her dreams impossible,
					
					Your voice, giving up rays of light:
					
					Is as important as life to her, poor thing,
					
					"She calls out to your retinue."
					
					Make my heart's sorrow great
					
					On that blissful topic,
					
					Write down a thought, acute, burning,
					
					On the covering of my consciousness!...
					
					Let this thought torment my consciousness,
					
					So that a strong fire may burn my heart,
					
					Let me hungry, thirsty for goodness,
					
					So I cannot be sated, so I may die hungry...
					
					Do not let me rest, ever,
					
					Let me always be troubled,
					
					Only then am I happy,
					
					When I am tormented;
					
					When my heart is caching fire,
					
					Then my consciousness thinks straight, -
					
					Then, I am free,
					
					Then, I feel unrestrained.
					
					Protect me with your right hand,
					
					And the hem of your robes,
					
					Until that time arrives
					
					Of my last sigh.
					
					My soul - is yours, my corpse -- belongs to the earth, -
					
					I no longer feel sorrow,
					
					The fish belongs to the water, to the sky - the stars,
					
					A child - to its mother and father
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					September, 1893
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					September, 1893
					</p>
				</div>
			</div>
		<?php
	bottom();
?>