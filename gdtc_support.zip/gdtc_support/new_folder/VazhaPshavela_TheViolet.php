<?php
	include("../gdtc_support/common.php");
	$title = "The Violet ,  ია";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">The Violet ,  ია</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Vazha-Pshavela ,  ვაჟა-ფშაველა</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Mary Childs, with Aida Lominadze</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2009</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Georgian in Seattle. Non-commercial Use Permitted, With Attribution
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>მცენარეა</li><li>&*
								მცენარეა</li><li>
								needs to be checked
								</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ვაჟა-ფშაველა</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Vazha-Pshavela</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1> ია</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>The Violet</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უღრანს ტყეში მოსული ვარ... მანამ ცოცხალი ვარ, ჩემის სილამაზით დავატკბობ 
					ტყეს, ბალახს და იმ გაღმიდამ გამომცქერალს გულხავსიანს კლდესა, სუნელებას 
					მივაფრქვევ არემარეს. ყველას ვუყვარვარ: აგერ იმ დამპალს ყუნჭს თვალი სულ 
					ჩემსკენ უჭირავს, მიცინის ხოლმე, უნდა ჩემთან მოვიდეს, - მაკოცოს, მაგრამ არ 
					შეუძლიან, მხოლოდ შორიდამ გამიცინებს, გაიღიმება საცოდავი, თუმცა უშნოდ, 
					მაგრამ გულკეთილობა კი დიდი გადაეფინება ხოლმე პირზედ. 
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I grew up in a dense, thick forest... as long as I'm alive,
					  with my beauty I bring sweetness to the forest, to the grass, and
					  that boulder, with its mossy chest, looking at me from the other 
					  side, and I pour forth a wonderful fragrance over the surrounding area. 
					  Everyone loves me: there, that rotten tree stump looks
					  only at me, it's always laughing in my direction, it wants to come to me,
					  -- to kiss me, but it can't; it laughs towards me only from a distance, and
					  smiles, the poor thing -- although it's ugly, still, a large,
					  kindhearted smile spreads over its face.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					განა მარტო იმას უხარიან ჩემი სიცოცხლე? წვერხმელი ხეებიც მე დამხარიან 
					ზევიდამ, თვითონ თავშიშველნი, ტოტებს მე მაფარებენ: ჩვენს იას არ შეგვიცივდეს, 
					ან არაფერმა არ აწყინოსო. პირდაპირ შხაპუნა წვიმას არ უშვებენ ჩემამდის: წვიმას 
					შეუძლიან ერთბაშად ჩამომაცალოს ფოთლები. უფოთლებოდ ყოფნა და სიკვდილი 
					ჩემთვის ერთია. არა, ხეები: არყი, წიფელი, თხილი, თამელი, დუდგულა გარშემო 
					მეხვევიან და მყარაულობენ, წვიმის ნამს ინახავენ ტოტებით, ფოთლებით და მერე 
					ნელ-ნელა მამცვრევენ პირზე თითო-ოროლ ნამობით, პირსა მბანენ, მე ყელს 
					მოვიღერებ და ვინატრებ, ნეტა სიმღერა შემეძლოს, ნეტავი</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Really, is it the only one who takes joy in my life? The withered crowns of
					  the trees enjoy me from above, and they themselves, with naked tops,
					  shield me with their branches:  so that we violets don't catch
					  cold, so that nothing harms us.  They don't allow heavy rain to fall
					  directly on me: the rain could tear off my leaves in an instant. To be
					  without leaves and death are one and the same for me.  No, the
					  trees:  birch, beech, hazelnut, chequer, elder all surround me
					  and watch over me, they save the raindrops for me with
					  their branches and leaves, and then slowly, gently let fall one
					  or two drops from above; they wash my face; I lift up my neck and
					  dream, if only I could sing, if only</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					13b</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					13b</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დამბადებელს ჩემთვის ნიჭი მოეცა. რომ მექო მაღლა ცა და ღრუბელი, მზე, ეს ჩემი მფარველი ხეები, ეს მთები, ის ჭალები და ღაბუა ჩიტები, რომელნიც ხმელს, ყვითელს ფოთლებში წითლის და მწვანის ფრთაბუმბულით ჩემს წინ დაგოგვენ და ხანდახან შემომჭიკჭიკებენ პირში, მათამაშებენ, უხარიანთ ჩემი სიცოცხლე. ჩემი ერთის თვის სიცოცხლე სხვის ოცდაოთხის თვის სიცოცხლეს სჯობია, მაგრამ დიდხანს სიცოცხლეს კი დანატრებული ვარ. დილას ერთმა ~წიფლისჩიტამ~ ჩემს ახლოს იგალობა, ლამაზი რამ იყო, - ყელწითელი, ღაბუა: იმასაც ჩემსავით თავი მოსწონდა, იხედებოდა გულზედ და მხრებზედ: ყველას მოსწონს თავი, ყველას უხარიან სიცოცხლე, ყველას უყვარს ბუნება.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					my creator had given me that gift. So I could praise the sky above
					  and the cloud, the sun, these sheltering trees of mine, these mountains,
					  those flood meadows, and bearded hens, which in the dry, yellow leaves, 
					  strut in front of me with their red and green plumage, and sometimes chirp 
					  right in my face, play with me, and fill my life
					  with joy. My life of one month is better than another's life of
					  twenty-four months, but still, I dream of having a long life.  In the
					  morning, a "wood warbler" was chanting close to me -- how beautiful
					  she was -- red-throated, jowly; and she, too, like me, was
					  pleased with herself, she was looking at her chest and her
					  shoulders; everyone is pleased with himself, everyone rejoices in life, everyone loves nature.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გუშინ ცამ იჭექა, ჭექა-ქუხილი ჩვენ არ გვაშინებს: ქუხილი წვიმის მომასწავებელია და წვიმა ხომ, ძუძუს გვაწოვებს დედამიწის გულზე. მზე-მამაა, ზევიდამ დაგვყურებს და გვეალერსება, თვალყურს გვადევნებს. წვიმის მოსვლა მცენარეთ - უხარიანთ, ყელამდის სიხარულით მოიყარნენ: ეხლა ისინი ახალს კაბებს და ქათიბებს ჩაიცმენ. აი ეს ორი დღეა, რაც ჩემი დობილი სასუტელაც* ამოჩნდა: უხარია, უხარიან საცოდავს, სულ თავს იქნევს დაბლდა და მაღლა, უკრავს თავს დედამიწას, მზის სინათლეს, მეჩურჩულება, ზღაპრებს მიამბობს სიცოცხლეზე, სიყვარულზე; ხანდახან კიდეც გაიკასკასებს, გადამეხვევა და მაკოცებს. გუშინ დილით მე და ჩემმა დობილმა ორივემ ვიტირეთ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Yesterday there was thunder in the sky, but thunder and lightening do
					  not frighten us: thunder is a harbinger of rain, and rain, after
					  all, gives us her breast to suck on the heart of the earth.  The sun is
					  our father, it looks down on us from above, and caresses us,
					  keeps an eye on us. When the rain comes, the plants rejoice, they are
					  filled to their chins with joy:  now they put on new dresses and
					  jackets.  Look, it's been two days, since my bosom buddy, the foxglove, has appeared: 
					  she is happy, she is happy for the pitiful; she
					  constantly nods her head up and down, she bows her head to the
					  earth, to the light of the sun, she whispers to me, she tells me
					  fairy tales about life, about love; sometimes she even bursts out
					  laughing, embraces me, and kisses me.  Yesterday morning 
					  my bosom buddy and I were both crying.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რა შეუბრალებელია კაცი?! რასაც კი დაინახავს, უნდა რომ თავის სასარგებლოდ მოიხმაროს. ალბათ ვერ აფასებს ჩვენს სილამაზეს! ჩვენ წინ კაცმა გამოიარა, ცალს მხარზედ ცული ედო, მეორეზედ თოფი ეკიდა. მიადგა ერთს მშვენიერს ტოტგადართხმულს წიფელს, დაუშინა ცული და წააქცია. საბრალო, როდესაც წაიქცა, დაიკვნესა. ჩვენს იქით გუგულისკაბა* ამოსულიყო და ჯერ ხმელს, ჩამოსულს ფოთოლს არ ამოსცილებოდა. როდესაც ხე წაიქცა, გადიყრეინა ზევიდამ ფოთლები და წითლად გამობჭყვინდა, ცრემლები დასხმოდა ჩაღრმავებულს გულში.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					How merciless is man!!  What ever he sees, he wants to use for his own benefit.  
					  Perhaps he can't appreciate our beauty! A man went past us, an axe was resting on one 
					  shoulder, a rifle hung from the other. He went up to a beautiful beech
					  with wide-reaching branches, he chopped it with his axe, and felled
					  it. The poor thing, it groaned when it fell.  Beyond us, an early purple orchid had come up, 
					  an had not yet raised up over last year's dry,fallen leaves.  When the tree fell, 
					  the leaves waved overhead, and the trunk glistened red, 
					  the tears flowed in the depths of its heart.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					14</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					14</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					შუადღის დროს დაღალულ-დაქანცული ქედანი მოვიდა და დაჯდა ჩვენს წინ თელის ტოტზე და დაიწყო ღუღუნი. უხაროდა იმასაც გაზაფხულის მოსვლა და ის, რომ მშვიდობით ნახა კიდევ ნაცნობი ადგილი. უცებ თოფი გავარდა, ქედანმა ხმა გაკმინდა, ჯერ ფეხით ჩამოეკიდა ტოტზე, მემრე, ძირს ჩამოვარდა, ჩემს წინ დაეცა. სისხლი წამოუვიდა ნისკარტიდან და თვალები დახუჭა: გადმონადენი სისხლი წვეთ-წვეთად დაეტყო ფოთლებზე. მე და სასუტელას კანკალი მოგვივიდა... მე გარკვევით არაფერი მესმის, მხოლოდ რაღაც ბუბუნი, გრიალი, ბუნდი ჟრიამული მოდის ჩემამდის.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At noon, a wood pigeon, tired and exhausted, came and sat down in
					  front of us on an elm branch, and began to coo. She too, rejoiced
					  that spring was coming and that, again, in peace, she saw a
					  familiar place.  Suddenly a rifle was heard, the wood pigeon fell silent,
					  at first she hung from the branch by her foot, then she dropped
					  down and lay in front of me.  Blood flowed out of her beak
					  and she closed her eyes; the blood falling in drops splashed on the leaves.  
					  The foxglove and I shuddered... I hear
					  nothing distinctly, only some kind of din, a roar, hazy clamour comes towards me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვაჰმე, რა საბრალო არი</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Alas, how wretched is</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ია, მოსული მთაზედა!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					the violet, born in the mountains!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბეჩავს დააზრობს სიცივე,</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Cold freezes the pitiful thing, </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ან ელვა დაჰკრავს თავზედა;</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					or lightening strikes its head;</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ღმერთს მიუცია საწყლისად</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					God gave to this unhappy one</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მოკლე სიცოცხლის ჟამია,</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					a short span of life,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ქვეყნისა მისგან შვენება</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					the beauty it gives the world</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთი ბეჩავი წამია.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					lasts a single pitiful minute.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ია დაიწყებს კდომასა,</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The violet begins to die,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დაიქვითინებს: "ვაჰმეო!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					it bursts out crying: "Alas!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თუ გამაჩინე, უფალო,</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					If you gave birth to me, O Lord,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დიდი დღე რად არ მამეო?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					why didn't you give me a long day?!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					15a</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					15a</p>
				</div>
			</div>
		<?php
	bottom();
?>