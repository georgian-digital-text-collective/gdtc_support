(function() {
	window.onload = function() {
		var title = document.getElementsByTagName("title")[0].innerHTML;
		var body = document.getElementsByTagName("body")[0];
		/*if (title === "Georgian Digital Text Collective") {
			body.style.background = "#fff url(http://depts.washington.edu/dtcg/design/davit_gareja_small.jpg) no-repeat center center";
		}else if (title==="Texts"){
			body.style.background = "#fff url(http://depts.washington.edu/dtcg/design/background2.png) repeat-x center center";
		}*/
	};
})();