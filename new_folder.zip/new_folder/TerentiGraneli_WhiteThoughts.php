<?php
	include("../gdtc_support/common.php");
	$title = "White Thoughts ,  თეთრი ფიქრები";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">White Thoughts ,  თეთრი ფიქრები</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Terenti Graneli ,  ტერენტი გრანელი</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Ed Raupp, Ketevan Chkheidze, Mari Manvelishvili</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2009</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Copyright© 2009 Georgian in Seattle. Non-commercial Use Permitted, With Attribution
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>needs to be checked</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ტერენტი გრანელი</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Terenti Graneli</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1> თეთრი ფიქრები</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>White Thoughts</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თეთრი ფიქრები სადღაც მიდიან,
					
					თითქოს ქარია ჩემი ცხოვრება.
					
					რა ვქნა, რომ აწი არ შემიძლია
					
					ამ შეცდომების გამოსწორება.
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					White thought are going somewhere,
					
					As if the wind is my life.
					
					What I have to do, that now I cannot
					
					to correct these mistakes.
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კარგია ასე ტაძარში შესვლა,
					
					ამ ქვეყანაზე მე მარტო დავრჩი
					
					აკადმყოფივით დავდივარ ეხლა,
					
					ასე უდროოდ მოკლული ბავშვი
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It is good to walk into church like this,
					
					I stay alone in the whole world.
					
					Now like an ill person I go,
					
					so untimely killed child.
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					NO DATE
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					NO DATE
					</p>
				</div>
			</div>
		<?php
	bottom();
?>