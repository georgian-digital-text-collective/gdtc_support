<?php
	include("../gdtc_support/common.php");
	$title = "The Other Bank ,  გაღმა ნაპირი";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">The Other Bank ,  გაღმა ნაპირი</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Nugzar Shataidze ,  ნუგზარ შათაიძე</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Mary Childs, with Lia Shartava</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2014</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Permission granted from Inteleki Press, Tbilisi, Georgia, to publish in password protected form, for University of Washington, February 9, 2015.
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>needs to be checked</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ნუგზარ შათაიძე</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Nugzar Shataidze</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1> გაღმა ნაპირი</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>The Other Bank</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ნოემბრის ბოლოს ამინდი გამოკეთდა -- გამოთბა.  ღამღამობით ზემოდან, წყლულეთის გორებიდან ისევ წამოვიდოდა, დაბლა ჩამოიწევდა ჯანღი, თქორავდა და ასფალტს ასველებდა.  დილით აუშვებდა ის სველი ასფალტი და ხევგაღმა წამოფაფხული ქედი ნისლებს, ნისლით ჩამოიბურებოდა იქაურობა, აღარ ჩანდა საცხოვრებელი კორპუსები, დაყრუვდებოდა მთელი კვარტალი, ძლივსღა ისმოდა ადამიანებისა და მანქანების დაგუდული ხმები, ბურუსში სკოლისაკენ ლანდებივით მიდიოდნენ ჩანთააკიდებულ ბავშვებიც.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At the end of November the weather improved -- it warmed up.At night, a thick fog would descend from above, from the hills of Ts'q'luleti, settle in low, drizzle, and dampen the asphalt.  In the morning, the wet asphalt would rise up and form into fog on the other side of the Ts'mopapkhuli ridge; the area was veiled in fog, you could no longer see the buildings where people lived, the entire quarter fell silent, you could barely hear the humming sounds of humans and cars. With their backpacks on, like ghosts, children would walk in the mist to school.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მაგრამ მზე რომ ამოვიდოდა, ნისლი აიკრიფებოდა და გამოაჩენდა აქამდე იდუმალებით მოსილ გარემოს: გაშიშვლდებოდნენ მაღალი, უშუქობისაგან ფანჯრებამოღამეგულ სახლები, ქვემოდ გაილანდებოდა ქალაქი -- ისიც უშუქო, მიუსაფარი.  სველ ასფალტზე საბურავების შრიალით მექროდნენ მანქანები.  ავტობუსის გაჩერებასთან შავი, ფულჩაბოროტებული ღრუბელივით იდგა ტრანსპორტის მომლოდინი ხალხი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					But when the sun came out, the fog lifted and the surroundings, previously covered in mystery, were revealed:  the tall buildings, their windows dark like night because of the lack of electricity, stood naked; below, the city was like a shadow -- also without electricity, exposed. The cars hurried along, their tires swishing on the wet asphalt. The people, waiting for transportation, stood like a black, oppressive cloud by the bus stop.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბატონი ილო ავტობუსს აღარ ელოდებოდა, ფეხით მიდიოდა ხოლმე მეტროს სადგურამდე, იქამდე კი, სულ ცოტა, ხუთი კილომეტრი მაინც იქნებოდა.  ეს არ ადარდებდო:  ჯერ ერთი, ფულს ზოგავდა, მეორე -- ჯანმრთელობისათვის სასარგებლოდ მიაჩნდა ფეხით სიარული და მესამე...ერთი ცუდი მხარე კე ჰქონდა ამ ყოველდღიურ მოგზაურობას -- ფეხსაცმელი უცვდებოდა.  მატონ ილოს ეცვა დიდი, ცხვირმობრეცილი ბათინკები, რომლებიც მან სარდაფში მოეძია, იარგად გარეცხა, გააშრო, წაუსვა შავი საცხი და გააპრიალა -- სულ ახლებს დაამსგავსა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Mr. Ilo no longer waited for the bus; he would usually walk to the metro, and it was quite close to there, maybe five kilometers.  This didn't bother him:  in the first place, he was saving money; in the second -- going on foot seemed beneficial to his health; and third... there was one bad side to traveling like this every day -- his shoes were wearing out.  Mr. Ilo wore big boots with turned up toes, which he'd found in his basement, washed well, covered with black oil and polished -- he'd made them look completely new.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მეტროსთან მოკლე გზით ჩადიოდა.  ეს გზე მოუყვებოდა გაუქმებულ სამანქანო ტრასას, ჩაუვლიდა გაყინულ საქვაბეს, სამრეცხაოს, ბენზინის ჩასასხმელ წერტილს -- იმასაც გაუქმებულს, მინებჩალეწილს; გავიდოდა ნაგავსაყრელზე და ქვემოთ, ღრმა ხევისკენ დაეშვებოდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He took a short cut down to the metro.  This way led past an abandoned main road, a non-working boiler factory, a laundromat, a gas station -- this, too, abandoned, with broken windows; it led by a rubbish heap and passed down towards the deep valley.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხევში მიქშუოდა პატარა მდინარე.  აქაფებული წყალი თავპირის მტვრევით მიხტოდა დიდ ლოდებზე, მიიმსხვრეოდა, მერე თანდათანობით მშვიდდებოდა და ბოლოს, როცა გაივაკებდა, მდორედ მიედინებოდა კლდის ნაშალით მოფენილ კალაპოტში.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					A small creek gurgled in the ravine.  The frothing water, crashing, jumped over the large boulders, smashed to pieces, then gradually grew quiet, and finally, when it became flat, calmly flowed into the river bed lined with broken slivers of rock.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხევზე ორთავ ნაპირზე ხარობდა სხვადასხვა ხეები და ბუჩქები, გაზაფხულზე ამოდიოდა მაღალი ბალახიც, გაიშლებოდა ათასნაირი ყვავილი. ბატონმა ილომ არ იცოდა მათი სახელები, თუმცა ზოგიერთს მაინც სცნობდა, მაგალითად ჭერმებს, რომლებიც აქეთ, რატომღაც, ძალზე ბევრი იყო, კიდევ ნუშებსა და მაყვლის ბუჩქებს.  გაზაფხულზე, რასაკვირველია, სცნობდა ყაყაჩოებსაც.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					On both sides of the ravine a variety of trees and bushes flourished; in the spring, tall grass came up, and a thousand kinds of flowers blossomed.  Mr. Ilo didn't know their names, although he recognized a few of them, for example the apricots, which for some reason grew profusely there, along with the almonds and blackberry bushes.  In spring, of course, he also recognized the poppies.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლო დროს, მოსახლეობამ ხევის აქეთა ნაწილი პატარ-პატარა ნაკვეთებად დაყო, შემოღობა და მიწა დაამუშავა.  ამ ნაკვეთებზე მოჰყავდათ კარტოფილი და მწვანილი, რგავდნენ, აგრეთვე პამიდორს, ბადრიჯანს, თესავდნენ სტაფილოს და ჭარხალს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Recently, the residents had divided this side of the ravine into very small plots, fenced them in, and were working the land. In those plots they planted potatoes and greens, and also raised tomatoes and eggplants, and sowed carrots and beets.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბატონო ილო გულდასმით ათვალიერებდა ხოლმე იმ ბოსტნებს.  კარგად მოვლილ კვლებს ან მწიფე პამიდვრით დახუნძლულ მაღალ ბუჩქებს რომ დაინახავდა, უხაროდა ძალიან და გულში აქებდა მათ პატრონებს.  ხანდახან შეათვალიერებდა თვითონაც რომელიმე ცარიელ ადგილს და ფიქრობდა:  რა იქნება, რომ შემოვღობო, გაზაფხულზე კი დავბარო და ერთი პატარა ბოსტანი მეც გავაშენოო.  პრინციპში არ იყო ძნელი საქმე -- ქარხანაში, სადაც იგი მთავარ ენერგეტიკოსად მუშაობდა, თავისუფლად შეიძლებოდა რკინის მილებისა და მავთულის ბადის შოვნა, მაგრამ ეს სურვილი მუდამ ცარიელ სურვილად რჩებოდა, რადგან ბატონი ილო არ იყო პრაქტიკული ადამიანი. </p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Mr. Ilo would look at those vegetable gardens attentively. When he saw the well cared-for furrows, or the tall bushes, bowed down with ripe tomatoes, he was very happy, and praised their owners in his heart. From time to time he would look over an empty place, and thing: what would happen, if I fenced it in, and in the spring dug it, and I, too, built a small veggie garden.  In princple, it wasn't a difficult thing -- in the factory, where he worked as the head power engineer, he could easily find iron pipes and wire nets, but this dream would remain forever an empty dream, because Mr. Ilo was not a practical person.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სამსახურში, როცა თავის პატარა ოთახში უსაქმოდ იჯდა, ხშირად აგონდებოდა ხოლმე ის ხევი, პატარა მდინარე, ჭერმისა და ნუშის ხეები.  აგონდებოდა ბოსტნებიც.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At work, when he would sit idly in his small office, he would often remember that ridge, the small river, the apricot and almond trees.  And he would remember the vegetable gardens as well.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ენერგეტიკული კრიზისისა და ნედლეულის უქონლობის გამო, ქარხანა არ მუშაობდა, მუშები უფასო შვებულებაში იყვნენ, მარტო ტექნიკური პერსონალი იღებდა მცირეოდენ ხელფასს კუპონების სახით და სამსახურისა და ამ ხელფასის დაკარგვის შიშით, ბატონი ილო, იძულებული იყო, ყოველდღე ევლო ქარხანაში. </p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Because of the energy crisis and the lack of materials, the factory wasn't working, and the workers were on unpaid vacation; only the technical personnel were getting a small salary, in the form of coupons, and because he was afraid of losing his job and this salary, Mr. Ilo was forced to go to the factory every day.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მივიდოდა, გააღებდა თავისი ოთახის კარს, დაჯდებოდა ჩაცმული, თავზე ქუდჩამოფხატული და კითხულობდა გაზეთს.  ზოგჯერ, მთავარ ინჟინერს ან მის მოადგილეს ეთამაშებოდა ჭადრაკს.  შემოუერთდებოდნენ საწარმოო განყოფილების ბიჭებისც, დაიწყებდნენ ძველი დროების გახსენებას, როცა ღვინო ნამეთი ღირდა, პური ოცდაათი კაპიკი, კარგი სამწვადე ხორცი კი სამი მანეთი.  ოცნებაში გაშლიდნენ სუფრას მწვადებით, მოხარშული დედლებით, თუშური ყველით, ცხელ-ცხელი ხაჭაპურებით დამშვენებულს.  ყლაპავდნენ ნერწყვს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He would go, open the door of his room, sit there fully dressed, with his hat pulled down low on his head, and read the newspaper.  Sometimes, he would play chess with the main engineer or his deputy.  The guys from the productions department would join them, and they'd start to remember the old times, when wine cost a single ruble, bread 30 kopeks, and good bbq meat three rubles.  In their dreams they were giving a party with shashlik, boiled chicken, cheese from Tusheti, all enhanced with piping hot khachapuri.["footnote -- a Georgian dish, like pizza, but with the cheese often enclosed between two layers of dough."]  They would drool at the thought.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზოგჯერ გაჩნდებოდა საიდანღაც ჭაჭის ორნახადი არაყი, იყიდდნენ ქარხნის გამოციებულ სასადილოში კარტოფილის თითო ღვეზელს, დალევდნენ, გახალისდებოდნენ, სითმო და წამიერი სიხარული ჩაუდგებოდათ გულებში.  ჰყვებოდნენ ათას რამეს, თანდათანობით შედიოდნენ ეშხში, აწყობდნენ მომავლის გეგმებსაც -- ისმოდა სიტყვები:  "პრივატიზაცია," "სააქციონერო საზოგადოება," "უცხოური ინვესტიცია," "ერთობლივი საწარმო," და სხვ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Sometimes, vodka, twice distilled from chacha would appear;["footnote:  a Georgian alcoholic beverage, like grappa, distilled from grape remains."] they would each buy a potato pasty in the factory's cold dining hall, drink up, grow cheerful, and warmth and momentary happiness would enter their hearts.  They would talk about a thousand things, gradually become excited, and build future plans -- you could hear the words:  "privitization," "joint-stock company," "foreign investment," "joint enterprise," etc.. </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ღამით დაღლილი და მობოშებული მოუყვებოდა ხევის ნაპირს.  სიბნელეში ძლივს მიიკვლევდა გზას შინისაკენ.  ქვემოდან ესმოდა მდინარის ხმაური.  ახლა უკვე აშინებდა ის ხევი, ის მდინარე.  ნაარყალს, დაძაბუნებულს უჭირდა აღმართზე სიარული.  ზოგჯერ, გაჩერდებოდა, ამოიღებდა ჯიბიდან ნიტროგლიცერინის აბებს და დაიდებდა ერთ ცალს ენაზე.  იდგა, ისვენებდა, სახზე ცივი ნაივი ელამუნებოდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At night, tired and slackened, he would follow along the edge of the ravine. In the dark, he could scarcely navigate the road toward his home.  He could hear the noise of the river from below.  By now, he was already afraid of that ravine, that river. Weakened, drunk on vodka, he had difficulty going up the hill.  Sometimes he would stop, take out tablets of nitroglycerin from his pocket, and put a drop on his tongue.  He'd stand, rest, and the cold breeze would caress his face.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლოს, როგორც იყო, ავიდოდა, ააღწევდა შინამდე.  ჩაბნელებული კორპუსის წინ კიდევ ერთხელ გაჩერდებოდა, კიდევ ერთ აბს დაიდებდა ენაზე და აუყვებოდა კიბეს.  სებნელეში გულმოდგინედ ითვლიდა სართულებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Finally, as it was, he would make it up, reach his house. He even stopped once in front of the darkened building, put yet another drop on his tongue, and went up the stairs.  In the dark, he counted the floors carefully.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ცოლი ლამპის შუქით განათებულ სამზარეულოში იჯდა და ეწეოდა.  ბავშვებს ეძინათ.  ნავთქურაზე გამურული ჩაიდანი შიშინებდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					His wife was sitting in the kitchen, illuminated by the light of a kerosene lamp, and smoking.  The children were sleeping.  The sooty tea-kettle was bubbling softly on the kerosene stove.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბატონი ილო მალულად ათვალიერებდა ცოლის გამხდარ მხრებს, მის ამოღამებულ თვალებს, მერე ჩამოუჯდებოდა შორიახლოს, აიღებდა ერთ ღერ სიგარეტს, მოუვლიდა სურვილი, რომ მისთვისაც ეთქვა იმ პრივატიზაციის, სააქციონერო საზოგადოებისა თუ ერთობლივი საწარმოს შესახებ, მაგრამ ხმას ვერ იღებდა, იჯდა და თითებშუა გაჩხერილ ოფილტრო სიგარეტს ჩუმად სრისავდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Mr. Ilo glanced stealthily at his wife's thin shoulders, her eyes with their dark circles, then sat down close to her, took up a cigarette, and felt like telling her about that privatization, joint-stock company, or joint enterprise, but he couldn't utter a word; he would sit, and silently fiddle with the cigarette stuck between his fingers.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დილით ისევ ნისლით ჩამოიბურებოდა იქაურობა, აღარ ჩანდა არაფერი.  მანქანები უხმაუროდ დადიოდნენ იმ ნისლში, ავტობუსის გაჩერებასთან უხმოდ იდგნენ ტრანსპორტის მომლოდინე ადამიანები.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					 In the morning, that area was again enveloped in fog; nothing was visible.  The cars moved noiselessly in that fog, the people waiting for transportation were standing, without a word, at the bus stops.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბატონი ილო ისევ ფეხით მიდიოდა:  ჩაუვლიდა გაუქმებულ საქვაბეს, სამრეცხაოს, ბენზინის წერტილს, გავიდოდა ნაგავსაყრელთან და ჩაუყვებოდა ხევის ნაპირზე, ტალახში გაკვალულ რბილ ბილიკს.  მიდიოდა და ათვალიერებდა ნაბოსტნარებს, სიცივისაგან აშუშულ, მოლეული პამიდვრის ბუჩქებს, ჯერ ისევ მწვანედ მოღაღანე ჭარხლის კვლებს, მოწყენილ კომბოსტოებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Mr. Ilo was again walking: he went past the abandoned boiler factory, the dry cleaner, the gas station, he walked past the garbage heap, and he passed by the edge of the ravine, in the soft path blazed through the mud.  He walked, and looked at the former vegetable gardens, shriveled from the cold, the bushes, emptied of tomatoes, and the rows of beets, still  shimmering with green, and the listless cabbages.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთხელ, ხუთშაბათს, ოცდაოთხ ნოემბერს, ჩვეულებისამებრ მიდიოდა ხევის ნაპირზე.  მიდიოდა ნელა, ზოგჯერ გაჩერდებოდა და ყურადღებით დააცქერდებოდა მავთულის ბადეზე შერჩენილ ლობიოს ბწკალს, ალუბლის მუქწითელ ფოთოლსა და ტალახში ჩასრესილ ლოკოკინას. ჩაათავა გვიანი შემოდგომის სევდით გაბრუებული ბოსტნები, ჩაუარა მიტოვებულ საწყობის შენობას, ნაგვით ამოვსებულ საცურაო აუზს და გამხმარი, გაყვითლებული ბალახით შემოსილ კორდზე ავიდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Once, on Thursday, November 24th, as usual, he was walking along the edge of the ravine.  He was walking slowly, he would stop from time to time and look carefully at the bean tendrils stuck in the wire mesh, the dark red leaves of the cherry tree, and the snails, crushed in the mud. He passed by the gardens stupified by the sadness of late fall, walked by an abandoned storage building, a swimming pool filled with garbage, and went up to a patch of land covered in dried, yellowed grass.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აქედან მოჩანდა ხევის გაღმა ნაპირი:  ნაშალი კლდის ძირში კონცხივით გამოწეული მომცრო, შემოუღობავი მიწის ნაჭერი, რომელზეც ორი ჭერამი ხარობდა.  ბოლო დროს სწორედ ის ადგილი ჰქონდა შეთვალიერებული, გუნებაში უკვე შემოეღობა და შიგ ერთი პატარა ქოხიც კი ჩაედგა. ახლა ფიქრობდა, რომ კარგი იქნებოდა თუ ხის ტახტსა და მაგიდას გამართავდა, დაჯდებოდა იმ ტახტზე, ნიდაყვებით მაგიდას დაეყრდნობოდა და იქნებოდა ასე...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					From there, the other side of the ravine was visible: a plot of land, unfenced, smallish, jutting out like rocky crag at the bottom of a sheer cliff; two apricot trees were growing there.  Recently, he had been looking precisely at that place, and in his mind had already fenced it in, and put up a small hut inside.  Now he was thinking that it would be good if he could put in a wooden bench and table; he would sit on that bench, lean his elbows on the table, and that's how it would be... </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჭერმებს ფოთოლი გაჰყვითლებოდათ -- ძირს, ჯერ ისევ სიმწვანე შერჩენილ ბალახზე ეყარა ის ფოთლები.  კონცხს გარშემო უვლიდა მდინარე.  მდორედ მიდიოდა ცივი, გამჭვირვალე წყალი, რომელშიც მკრთალად ილანდებოდა ბალახიანი ნაპირი, ნაშალი კლდე, ის ორი ჭერამი და ამ ყველაფერს -- მიწას, ჭერმებს და მდინარეს თავზე ადგა თხელი, გაცრეცილი ნისლის პატარა ფთილა, რომელიც ნელა, ოდნავ შესამჩნევად ილეოდა და როცა, მოულოდნელად ახლადამოსული მზის სხივი მიწვდა, ჯერ ნარინჯისფრად აფორაჯდა, მერე თვალსა და ხელს შუა გაილია, გაილია და გაქრა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The leaves of the apricot tree were turning yellow -- they lay on the ground, on the still-green grass. The river flowed around the rocky crag.  The cold, transparent water flowed calmly, the grassy bank, the collapsing cliff, the two apricot trees reflecting in it faintly; and everything there -- the earth, the apricots, and at the head of the river floated a flock of thin, pallid fog, which slowly, scarcely noticeably disappeared; and when the rays of the sun had unexpectely reached that spot, everything seemed dappled orange, then faded between his eyes and hand, faded, and disappeared.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უეცრად, გამოხტა, წამოვიდა იქითა მხრიდან ერთი შავი ყორანი, ფრთების ფართხუნით გადმოუფრინა ხეებს, ავიდა მაღლა, სულ მაღლა, ყრანტალით გასწია ბურუსით მოცული ქალაქისაკენ და ბატონამა ილომ საკვირველი შვება იგრძნო, შვებაც და სიხარულიც; უცნაური კი იყო, მაგრამ მოეჩვენა, რომ იქ, გაღმა ნაპირზე მისთვის განკუთვნილი ადგილი გამოთავისუფლდა, გამოთავისუფლდა იმავე ნაპირის სურვილითა და იდუმალ ნებით. </p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Suddenly, a black raven jumped out, came out from that side, and with a flap of its wings flew to the trees; it flew up high, very high, and cawing, it headed towards the city, covered in fog, and Mr. Ilo felt an amazing sense of relief, both relief and joy:  it was strange, but it seemed that there, on the other side, a place set aside just for him was being freed up, and it was being freed up by the wish of that same side, and by a mysterious will.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თითქოს რაღაც ძალა ეწეოდა იქით, როგორც ვაკუუმი ისრუტავს ჰაერს, ისე ისრუტავდა ბატონ ილოსაც ის ცარიელი ადგილი და გრძნობდა, როგორ თანდათანობით იშლებოდა, ნაწევრდებოდა, ნელ-ნელა როგორ ავსებდა კუთვნილ ადგილს, რანაირად გადადიოდა აქედან -- იქით...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It was as if some kind of force was pulling him there, as a vacuum sucks air, so the empty space was sucking Mr. Ilo, and he felt how gradually he was disintegrating, falling to pieces, how very, very  slowly he was filling up his proper place, in some way he was going from here -- to there... </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დიდხანს არ გაგრძელებულა ეს უცნაური, დაუჯერებელი რაღაც.  იმ ადგილზე, სადაც წეღან ბატონი ილო იდგა, ბალახს მისი დიდი, ცხვირმობრეცილი ბათინკების კვალიღა აჩნდა.  ბალახი სწორდებოდა, ცახცახებდა, წელში იმართებოდა, თანდათანობით ქრებოდა ის ნაკვალევიც.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					 This strange, unbelievable sensation did not last long.  In that place where Mr. Ilo stood earlier, in the grass, the prints of his big boots with their turned up toes appeared.  The grass was becoming smooth, trembling, straightening up. Gradually, those footprints disappeared.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					იმ დღეს ბატონი ილო ქარხანაში აღარ მისულა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					That day, Mr. Ilo no longer went to the factory.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					date unknown</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					date unknown</p>
				</div>
			</div>
		<?php
	bottom();
?>