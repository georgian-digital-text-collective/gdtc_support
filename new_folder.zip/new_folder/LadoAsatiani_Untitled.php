<?php
	include("../gdtc_support/common.php");
	$title = "Untitled , Untitled";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">Untitled , Untitled</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Lado Asatiani ,  ლადო ასათიანი</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Mary Childs, with Maka Janikashvili</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2011</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Georgian in Seattle. Non-commercial Use Permitted, With Attribution
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>needs to be checked</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ლადო ასათიანი</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Lado Asatiani</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1>Untitled</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>Untitled</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვიდრე სიკვდილი გამახვევდეს ბნელს მოსასხამში
					
					ვიდრე სიკვდილის ჭვალი გულზე დამესობოდეს,
					
					უკანასკნელად დამაწვინეთ ჩემს ოდა სახლში,
					
					უკანასკნელად, ვიდრე თვალნი დამევსებოდნენ.
					
					უკანასკნელად პაპიჩემის გაჯორკილ ტახტზე
					
					დამიგეთ მაგრად, დამახურეთ შავი ნაბადი,
					
					უკანასკნელად უდრტვინველად მამყოფეთ ასე,
					
					ვიდრე სიკვდილი შფოთიან სულს გამინაბავდეს.
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Before death wraps me in its dark shroud,
					
					Before death's seal makes it mark on my heart,
					
					For the last time let me visit in my ancestral home,
					
					For the last time, before my eyes go dark on me,
					
					For the last time on my grandfather's wooden plank bed
					
					Make for me a firm surface, cover me with a black nabadi,
					
					For the last time let me be like this, untouched,
					
					Before death brings silence to my turbulent soul.
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					1941
					</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					1941
					</p>
				</div>
			</div>
		<?php
	bottom();
?>