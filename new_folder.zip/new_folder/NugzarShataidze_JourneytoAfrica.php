<?php
	include("../gdtc_support/common.php");
	$title = "Journey to Africa ,  მოგზაურობა აფრიკაში";
	top($title); ?>
				<h1><?= $title ?></h1>
				<h1 class="get">Journey to Africa ,  მოგზაურობა აფრიკაში</h1>
			</article>
		</article>
		<article>
			<div class = "row" id = "row">
				<div class="col-lg-8 col-lg-offset-2">      
					<table class="table table-condensed table-hover">
						<thead>
						<tr>
						<th>Category:</th>
						<th>Descriptor:</th>
    					</tr>
						</thead>
						<tbody>
							<tr>
								<td>Author:</td>
								<td>Nugzar Shataidze ,  ნუგზარ შატაიძე</td>
							</tr>
							<tr>
								<td>Publisher:</td>
								<td></td>
							</tr>
							<tr>
								<td>City:</td>
								<td></td>
							</tr>
							<tr>
								<td>Editor:</td>
								<td></td>
							</tr>
							<tr>
								<td>Translator:</td>
								<td>Mary Childs</td>
							</tr>
							<tr>
								<td>Edition:</td>
								<td>Electronic Version</td>
							</tr>
							<tr>
								<td>Responsibility:</td>
								<td></td>
							</tr>
							<tr>
								<td>Date:</td>
								<td>2014</td>
							</tr>
							<tr>
								<td>Copyright:</td>
								<td>
								Copyright 2014 DTCG. All Rights Reserved.
								[FOR PRINT: Get standard wording] DTCG grants non-profit academic users a limited, non-exclusive right to copy and print this work with attribution. This right does not include use of this material in derivative works.
								[NOT FOR PRINT: Get standard wording]This work is not yet available for print-on-demand.
								</td>
							</tr>
							<tr>
								<td>Notes:</td>
								<td><ol><li>needs to be checked</li></ol></td>
							</tr>
							<tr>
								<td>Text ID:</td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</article>    
		<article>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
                	<h2> ნუგზარ შატაიძე</h2>
				</div>
				<div class="col-lg-4 english">
					<h2>Nugzar Shataidze</h2>
				</div>
			</div>
			<div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<h1> მოგზაურობა აფრიკაში</h1>
				</div>
				<div class="col-lg-4 english">
					<h1>Journey to Africa</h1>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p class = "pb">
					Page: 1
					</p>
				</div>
				<div class="col-lg-4 english">
					<p class = "pb">
					Page: 1
					</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზოგს რა უყვარს, ზოგს -- რა, მე კი ყველაფერს ძილი  მირჩევნია.  ჭამაც კარგია, მაგალითად ცხელი სუპი ან კატლეტი კარტოფილის პიურეთი, მაგრამ ძილი უკეთესია.  განსაკუთრებით დილის ძილი, როცა ცივა, შენ კი ჩათბუნებული წევხარ და არხეინად გძინავს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Some people like one thing, others, another, but I prefer sleeping most of all.  Food is also good, for example, hot soup or steak and mashed potatoes, but sleep is better.  Especially morning sleep, when it's cold, and you're lying all warm and cozy and sleeping peacefully.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					წინათ, დედასთან რო ვცხოვრობდი, ძილი არ მიყვარდა.  მაშინ ჩემი ლოგინიც მქონდა და ყველაფერი, მაგრამ დედა რომ მეტყოდა, დაწექი, ბიჭო, დაიძინე, გვიანიაო, არ ვუჯერებდი.  მერჩევნა ტელევიზორისთვის მეყურებინა ან ბავშვებთან ერთად მეთამაშა სასტუმროს დერეფანში.   ახლა არა, ახლა ძილი მერჩევნია.  დავწვები თუ არა, მაშინვე ჩამეძინება ხოლმე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Earlier, when I was living with my mother, I didn't like to sleep.  Then, I had my bed, and everything, but when my mom told me, lie down, my son, go to sleep, it's late, I didn't do what she said.  I preferred watching tv or playing together with the kids in the hotel hallway.  But now, no, now I prefer sleep.  Usually, as soon as I lie down, I fall asleep right away.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სანამ ამ სარდაფს მოვაგნებდი, ძალიან ვწვალობდი -- მე და წუპაკა დიღმის ტრასაზე, "ალეაში" ძველ პაკრიშკას ვანთებდით ხოლმე და ცეცხლთან ჩამომსხდრები ვიძინებდით.  ახლა აქ მძინავს.  მოვალ, შევძვრები მუყაოს ყუთში და გავეხვევი ამ ჩემს საბანში.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Before I found this cellar, I struggled a lot -- Tsupaka and I used to light old tires in an alley, off the main road in Dighomi, and we would sleep, crouched by the fire.  Now I sleep here. I'll come, slip into my cardboard box, and wrap up in my blanket.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გაგიკვირდებათ, საბანი საიდან:  საახალწლოდ თემქაზე კორპუსებს ჩამოვუარე -- ძველი ტანსაცმელი გექნებათ-მეთქი და მაშინ მომცეს.  ესა და თბილი ბუშლატი.  ბუშლატი დიდი მქონდა, მაგრამ სახელოები გადავუკეცე და მშვენივრად მომადგა.  ყუთი კი ელიავას ბაზრობაზე დავითრიე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					You'll be amazed where the blanket's from: on New Year's Eve, in the Temka neighborhood, I went knocking on doors in the apartment complexes, asking if they happened to have any old clothes, and they gave me some.  This, and a warm peacoat.  The peacoat was too big for me, but I rolled up the sleeves and it fit me beautifully.  And I got the box from the Eliava market.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მუყაოს ყუთში ძილი სოხუმელმა მიჭმა გოშკამ მასწავლა.  კაი რამეა, გარედან სიცივეს არ უშვებს, შიგნით -- სითბოს.  მაგრამ როცა ყინავს, მაშინ მაინც ცივა.  ღამით გეღვიძება, კანკალებ, არც საბანი გშველის და აღარც ყუთი.  ამ დროს უნდა ადგე და ირბინო, ან ერთ ადგილზე იხტუნო, მაგრამ რაზეა ლაპარაკი, პაკრიშკას მაინც ეს სჯობია.  დილაობით მე და წუპაკა რომ გავიღვიძებდით, ისე ვიყავით გამურულები, ზანგებს ვგავდით -- მარტო თვალები და კბილები...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					A boy from Sokhumi, Goshka, taught me how to sleep in a cardboard box.  It's cool, it doesn't let the cold in from the outside, and inside, it keeps the heat in.  But when it's freezing, then it's still cold.  You wake up in the night, shiver, and neither the blanket nor the box helps you any more.  Then, you have to get up and run, or jump in place, but what can you say, this is still better than old tires.  When Tsupaka and I would wake up in the morning, we'd be all dark from soot, we looked like blacks -- only our eyes and our teeth</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					255</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					255</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გვიჩანდა.  დავცინოდით ხოლმე ერთმანეთს.  მერე წუპაკა აცეტონზე შეჯდა და ბოლომდე ჩაეშვა, სულ გათიშული დადიოდა.  აი, ხო გელაპარაკებოდა არა, ჩვეულებრივად, უცებ აურევდა, სულ სხვაგან წავიდოდა, ბოდავდა თუ რა იყო, არ ვიცი -- ხან დედას მეძახდა, ხან მამას, ხანაც რა ვიცი -- რას.  ბოლოს მოკვდა.  ამბობდნენ, გაიყინაო, მაგრამ ტყუილია, აცეტონით მოიწამლა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					were visible.  We'd make fun each other. Then Tsupaka got hooked on acetone and he bottomed out. He'd walk, around completely out of it. It's like, he'd be talking with you normally, and suddenly he'd lose it -- sometimes he called me 'mom,' sometimes 'dad,' and sometimes, I'm not sure what.  In the end, he died.  They said that he froze to death, but that's a lie.  He overdosed on acetone.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ეს სარდაფი რო არ მეშოვნა, მეც წუპაკასავით დამემართებოდა რადგან, როცა კაიფობ, აღარ გცივა, უფრო სწორად, სიცივეს ვეღარა გრძნობ.  თანაც, თითქოს ტელევიზორს უყურებო, ხედავ როგორ მოდიან სპილოები, ლომები, ჟირაფები.  მოდიან და მოდიან, შენ კი უყურებ.  მაგრა ასწორებს.  ტელევიზორზე კარგია.  არ ვიცი, როგორ ვთქვა...ეს ცხოველები რომ მოდიან, შორიდან კი არ უყურებ, შენც იქა ხარ, მათთან ერთად.  ზოგჯერ ისე ახლოს ჩაგირბენენ, რომ ზედ გაგეხახუნებიან და ამ დროს გრძნობ მათ სუნს, სითბოს...ზებრას, მაგალითად, იცი, რისი სუნი აქვს? -- ცხენისა.  სპილოები ჯოგებად მოდიან -- შვიდნი, რვანი, ცხრანი.  მარტორქები თითო ან ორ-ორი, მეტი არა; ანტილოპებს ხო ვერც დაითვლი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					If I hadn't found this cellar, I would've ended up like Tsupaka, too, because, when you're high, you're no longer cold, or really, you no longer feel the cold.  And at the same time, it's almost like you're watching tv, you see how the elephants, lions, and giraffes are walking.  They walk and they walk, and you're watching.  It's really, really cool.  It's better than television.  I don't know how to describe it... when these animals are walking, you aren't watching them from a distance, you're right there, with them.  Sometimes they run by you so closely that they almost brush up against you and then you can smell their scent, their warmth... zebras, for example, do you know what they smell like?  A horse.  The elephants travel in herds -- seven, eight, nine.  The rinocerous, one at a time, or in twos, not more; and you can't even count the antelopes.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ყველაზე მაგრა ლომებზე ვკაიფობ -- გამხმარ ბალახში წვანან და ზებრებს ყვითელი თვალებით უყურებენ.  ზებრებს და კამეჩებს.  ამ დროს განა გძინავს, გღვიძავს, მაგრამ აქ კი არა ხარ, იქა ხარ, იმ გამხმარ, წელამდე ბალხში დგახარ და გესმის როგორ მოდიან და მოამტვრევენ კამეჩები ფეხით ლელიანს, როგორ სტვენენ და ჭიკჭიკებენ ჩიტები, რანაირი დგრიალით გადაივლიან ზებრები განიერ მინდორს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I think the lions are coolest of all -- they lie in the dry grass and watch the zebras with their yellow eyes.  The zebras and the water buffalo. Then, you're not really sleeping, you're awake, but you aren't here, you're there, standing in the dry grass that reaches up to your spine, and you hear how the water buffalo are walking, trampling the reeds with their feet, how the birds are whistling and chirping, how the zebras thunder across the wide field.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მაგარი კაიფია, თანაც იაფი, ტუბიკი -- ლარი.  ჩვეულებრივი წებოა, აცეტონიანი -- "ბე-ეფი".  ეგ ჩაუშვი ცელოფანის პარკში და დავაი, ისუნთქე!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It's a good high, and cheap -- a small tube is a lari [approx. 10-30cents].  It's regular glue, acetone, "BP".  You put it in a plastic bag, and there you go [The characters use Russian, written in Georgian script, for slang: დავაი давай davai] -- breathe in!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					წუპაკა 23 დეკემბერს მოკვდა. მაშინ დიდი თოვლი მოვიდა, ღამით ყინავდა.  პაკრიშკა აღარა გვშველოდა და რა გვექნა, წებოს ვსუნთქავდით.  დილით გავიღვიძე და ვხედავ, ტოვლზე...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Tsupaka died on December 23.  It was snowing heavily then, at night it was freezing.  The tire wasn't helping us any more, and what could we do, we sniffed glue.  In the morning, I woke up and saw he was lying</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					256</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					256</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					...აგდია მოკრუნჩხული.  ჯერ მეგონა ეძინა და ნჯღრევა დავუწყე, არ გაცივდეს-მეთქი, მაგრამ ბოლოს მივხვდი რომ მომკვდარიყო.  ეგრევე გამოვიქეცი.  დიღმის მასივში ჩავედი, ტროლეიბუსს დავაჯექი და მეტროსთან გავედი.  წუპაკაზე კრინტი არავისთან გამიძრავს, მეშინოდა ჩემთვის არ დაებრალებინათ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					curled up on the snow. At first I thought he was sleeping, and I started to shake him so he wouldn't get cold, I told myself, but finally I realized that he had died.  I ran away immediately.  I went down to Dighomi Massif, got on a trolley, and headed for the metro.  I didn't breath a word to anyone about Tsupaka. I was afraid they would blame me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მას მერე აღარ მიკაიფია.  აღარც მინდა.  გაზაფხულამდე რაღა დარჩა -- თებერვალი და მარტი -- ორი თვე.  აპრილში უკვე თბილა.  თანაც, ხო ვთქვი, ეხლა უკვე სარდაფში ვიძინებ.  სახლი, ეტყობა, მიწისძვრის დროს დაინგრა და მიატოვეს, ეს სარდაფი კი გადარჩა.  ერთი ეგ არი, შიგ ცეცხლს ვერ ვანთებ, რადგან ბოლი დგება, თორემ ისე ძალიან კარგია.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					After this, I no longer got high.  And I no longer wanted to.  There wasn't much time left until spring -- February and March -- two months.  It's already warm in April.  And besides, as I've said, now I'm already sleeping in the basement.  The house, it seems, collapsed in an earthquake and was abandonned, but this basement is still here. There's one problem -- I can't light a fire inside, because it gets smokey; otherwise, it's pretty good.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ის ბიჭი -- წუპაკა, უპატრონო მეგონა, თვითონვე ამბობდა, არავინა მყავსო, მაგრამ მისი სიკვდილის მერე ვიღაც გოგო მოვიდა, შენ ჩემი ძმის მეგობარი ყოფილხარო და თხუთმეტი ლარი მაჩუქა.  შემრცხვა და არ ვართმევდი, მაგრამ ჯიბეში ძალით ჩამიდო.  მერე გოშკამ მითხრა, რომ იმ გოგოს ლუიზა ერქვა და ცირკთან იდგა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					This boy -- Tsupaka, I thought he had no family, and he actually said he had no one, but after his death some girl came to me and said, "You're my brother's friend," and gave me fifteen lari.  I was embarrassed and didn't want to take it, but she forced it into my pocket.  Then Goshka told me the girl's name was Louisa, and that she worked as a prosititue near the circus.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თხუთმეტი ლარი ბევრი არ არი, მაგრამ არც ცოტაა.  მე დღეში ზოგჯერ ხუთი და ექვსი ლარიც მიშოვნია.  უნდა იცოდე, ვის სთხოვო, თავი როგორ შეაცოდო.  ყველა კი არ მოგცემს.  ყველას არცა აქვს, მაგრამ ურჩევნია ისე მოგაჩვენოს, ვითომ აქვს, მაგრამ არ ემეტება.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Fifteen lari isn't much, but it isn't a little, either.  Sometimes I've five or six lari a day.  You have to know whom to ask, how to behave.  Not everyone gives.  Not everyone has money, but they prefer to pretend they do, but that they don't want to give it away.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბიჭი და გოგო ერთად რომ მოდიან, ბიჭს უნდა უთხრა -- გეხვეწები, ათი კაპიკი მაჩუქეო და თუ აქვს, აუცილებლად მოგცემს.  გოგო თუ მარტოა, მაშინ ხო, მაგრამ სხვებთან თუ არი და სთხოვე, არ მოგცემს, დაახვიე აქედანო, გეტყვის. ბიჭი, მარტო თუ არი, ზედაც არ შემოგხედავს.  ბევრ ბიჭს ერთად კი უნდა ერიდო, რადგან შეგაგინებენ და წიხლსაც ამოგარტყამენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When a boy and a girl are walking together, you have to say to the boy -- please give me ten kopeks, and if he has it, he'll absolutely give it to you.  If a girl is alone, then yes, but as soon as she's with others and you ask, she won't give, she'll tell you to get lost. A boy, if he's alone, won't even look at you. You have to avoid a group of boys, because they'll swear at you and kick you.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მიწისქვეშა გადასასვლელები და ეკლესიების შესასვლელები დაკავებულია.  მიწისქვეშაში მოხუცი კაცები დგანან, ზოგი ვითომ ბრმაა, ზოგიც -- ხეიბოარი.  იქ არიან ბოშებიც...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The underground passageways and the church entrances are taken.  Old men stand in the underground passages, some of them pretend to be blind, some, disabled.  There are also gypsies</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					257</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					257</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					...თავიანთი პატარა, გამურული ბავშვებით, ეკლესიებთან კი მოხუცი დედაკაცები ბატონობენ, ისინი იქიდან ერთმანეთს აგდებენ და შენ რას მიგიშვებენ.  არადა იქ ყველაზე კარგია, რადგან მორწმუნე ადამიანი მოწყალებას ადვილად იმეტებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					with their small, sooty children, and the old women lord over the entrances to the churches; they push each other away, and don't let you near.  But still, it's the best there, because a religious person readily givew away to charity.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხალხის უმეტესობას ფული არა აქვს და ვერც ვერაფერს იძლევა, ფულიანები კი ქუჩაში ფეხით არ დადიან, ისინი მანქანებში სხედან.  შეიძლება შუქნიშანთან დადგე და წეთელზე რომ გააჩერებენ, მაშინ სთხოვო ოცი თეთრი, მაგრამ იქაც დაკავებულია, ყველა შუქნიშანთან უკვე სხვები დგანან და გამოგაგდებენ, ამიტომ იძულებული ხარ კაფეში ან სასაუზმეში შეხვიდე.  არც ეს არის ადვილი -- ოფიციანტები თავში გირტყამენ, გაგინებენ, მაგრამ არ უნდა შეშინდე, სანამ ისინი დაგინახევენ, ერთი ორმოცი-ორმოცდაათი თეთრის შონვას მაინც მოასწრებ.  თანაც, იქ თბილა და საჭმელების სასიამოვნო სუნი ტრიალებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The majority of people don't have money, and they aren't able to give anything; and the wealthy don't travel on the streets by foot, they ride in cars.  It's possible to stand by the stoplights and when they stop at a red light, then you can ask for twenty tetri ["100th of a lari; like a penny"], but even those spots are busy, others are already standing at every stoplight, and so you're forced to go to a cafe or a diner.  And even this isn't easy -- the waiters whack you on the head, swear at you, but that shouldn't scare you, because before they notice you, you still have time to find 40-50 tetri.  And in the meantime, it's warm there, and the aroma of food swirls all around you.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მეტროშიც თბილა.  მეტროთი ვინ დადის, სულ უბრალო ხალხი, არა?  ხო და, რო იცოდე, ეს უბრალო ხალხი უფრო მეტს იძლევა.  მაგრამ მეტრო იმით არი ცუდი, რომ იქ პოლიციაა.  ერთხელ დამიჭირეს, მაგრა მცემეს და იმ დღეს ნაშოვნი მთელი ფული -- სამლარნახევარი სულ წამართვეს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It's warm in the metro, too. Who takes the metro -- completely simple people, right?  Yes, and, you know, these simple people give the most.  But the metro is bad in one way -- the police are there.  Once they grabbed me, beat me up badly, and took away all the money I'd gotten that day -- six and 1/2 lari.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მეტროში უფრო გოგოები ჩალიჩობენ.  იმათაც კი იჭერენ, მაგრამ არა სცემენ და არც ფულს ართმევენ, მარტო აწვალებენ და ატირებენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Mostly girls hustle in the metro.  And they catch them too, but they don't beat them up, and don't take away their money, they just torment them and make them cry.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზოგს მათხოვრობა უტყდება და ამიტომ ვითომ ყიდის, რაღაც-რაღაცებს დაატარებს, მაგალითად, საეკლესიო წიგნებს, კედლის კალენდრებს, სანთებილებს.  ხალხს ისინი ეცოდება და ფულს აძლევენ.  რუსთაველზე ერთი პატარა, ათი თუ თერთმეტი წლის ოჩამჩირელი ბიჭი ფერადი ფანქრებით დახატულ საკუთარ ნახატებს ყიდიდა, ცალს ორ ლარად და კარგ ფულსაც შოულობდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Some people don't like to ask for money, and so they pretend to be selling, they carry things, like church books, wall calendars, lighters.  People pity them, and give them money.  On Rustaveli Avenue, one small boy from Ochamchire, 10-11 years old, used to sell his own drawings, done in colored pencils, and he'd earn two lari a piece, and make good money.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კვირაში ერთხელ ავტობუსით საჭმელი მოაქვთ.  ქაშვეთთან ველოდებით ხოლმე.  ავტობუსში ორი კაცია -- უშანგა და რეზო და ერთი ქალი -- მანანა.  მოვლენ, დაგვისხამენ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Once a week they bring food by bus.  We used to wait by Kashveti Church.   There were two men in the bus -- Ushanga and Rezo, and one women - Manana.  They would come, pour</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					258</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					258</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					პლასტმასის ჯამებში სუპს და მოგვცემენ თეთრი პურის ორ-ორ ნაჯერს.  სუპი მიყვარს, ამიტომ ვამატებინაბ ხოლმე.  თვითონვე გვეუბნებიან, თუ გინდათ, დაგიმატებთო.  მერე ჩაის გვასმევენ ან კამპუტს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					soup for us in plastic bowls and offer us two slices of white bread.  I like soup, and used to ask for more.  They actually said, "If you'd like, we'll give you more."  Then they served us tea or compote. ["a beverage made from boiled fruit"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთხელ დეიდა მანანა მეკითხება, მართლა არავინა გყავსო?  არა-მეთქი, ვინმე რომ მყავდეს, ქუჩში რატო ვიქნებოდი-მეთქი. აფტობუსში ერთმანეთის გვერდით ვისხედით და ვლაპარაკობდით, ის რაღაც თბილად, ალერსიანად მიყურებდა და უცებ, ვხედავ, დედაჩემისნაირი თვალები არა აქვს?! -- ერთი მწვანე და მეორე ცისფერი.  არ ვიცი, რა დამემართა, ყელში რაღაცა გამეჩხირა, ხელი გამოვართვი და ზედ ვაკოცე, მაგრამ მაშინვე მივხვდი, რა სისულელეც ჩავიდინე და თავპირისმტვრევით გამოვიქეცი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Once, aunty Manana asked me, "Do you really have no one?" "No," I said, "if I had someone, why would I be out on the street?"  We sat next to each other in the bus and were talking; she was looking at me somehow warmly, caressingly, and suddenly I saw -- she has eyes like my mother's?! One was green, the other was blue.  I don't know what happened, something got stuck in my throat, I took her hand and kissed it, but right away I guessed I'd done something foolish and ran away as fast as I could.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მას მერე სუპს მე თვითონ ვიხარშავ.  ვყიდულობ ოცკაპიკიან სუპის პაკეტს და შინ მიმაქვს.  სარდაფში ბოლი დგება და ამიტომ ცეცხლს გარეთ ვანთებ, კედლის ძირში.  იქ ორ აგურზე დავადგამ ალუმინის გამურულ ჯამს, შიგ წყალს ჩავასხამ, რო ადუღდება, პაკეტს გავხსნი და ყველაფერს იმ ჯამში ჩავყრი.  გამოდის მაგარი სუპი, ისეტი, რომ ჭამით ვერ გაძღები.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					After that, I boiled soup myself.  I buy twenty-kopek packets of soup and take them home.  Smoke gathers in the basement, and so I light a fire outside, at the base of the wall.  There, I stand a sooty, aluminium bowl on two bricks, pour water inside, and when it boils, I open a packet and pour everything inside the bowl.  It's excellent soup, the kind I can never get my fill of eating.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აქამდე მეგონა, სხვადასხვა ფერის თვალები მარტო დედაჩემს ჰქონდა.  თურმე არა, სხვებსაც ჰქონიათ მამაჩემს თაფლისფერი თვალები აქვს, მეც, დედაჩემს კი ცალი ცისფერი, მეორე -- მწვანე.  არ მახსოვს, ვინმეს შეემჩნიოს და არ გაჰკვირვებოდეს -- უი, ქეთო, ეგ როგორი თვალები გაქვსო!  დედაჩემს ამაზე სულ მუდამ ეღიმებოდა ხოლმე, თითქოს ამაყობდა კიდეც, სხვებს რომ არ ჰგავდა, მაგრამ ბოლო ხანებში ის თვალები ერთი ფერისა გაუხდა, ორივე გაუნაცრისფერდა.  იქნებ იმიტომ რომ სმას მიეჩვია.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Until now, I thought, that only my mother had eyes of different colors.  It turns out no, others have them as well.  My father has honey-colored eyes, and me, too, but my mother has one blue, the other -- green.  I don't remember anyone noticing them, and not be surprised -- "Ooh, Keti, what eyes you have!" My mother would always smile at this, as if she were even proud, that she wasn't like others, but recently her eyes have taken on a single color; both of them are ash-grey.  Maybe because she's started drinking.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სიმთვრალეში ცუდი ხასიათი ჰქონდა:  დამსვამდა და დამიწყებდა ლაპარაკს, ხან რას მეუბნებოდა, ხან -- რას.  მერე თანდათანობით ბრაზდებოდა, სულ ცოფებს ყრიდა, თითქოს მე ვიყავი დამნაშავე იმაში, რომ ტყვარჩელში სახლი მივატო</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When she's drunk, she gets in a bad mood:  she'd sit me down and start talking at me, sometimes saying one thing, sometimes, who knows what.  Then gradually, she'd get angry, start frothing at the mouth, as if I were guilty for the fact that we left our house in Tq'varcheli</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					259</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					259</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვეთ და გამოვიქეცით, რომ მეათე წელია მამაჩემისა არაფერი ისმის, რომ თვითონ გამყიდველად მუშაობს ცივ ჯიხურში, რომლის პატრონი, ერთი ავყია დედაკაცი სულ მუდამ ქურდობას აბრალებს, მერე კი, როცა გამოირკვევა, რომ არაფერიც არ დაკარგულა, ბოდიშსაც არ უხდის.  თითქოს იმაშიც მე ვიყავი დამნაშავე, რომ გალოთდა, რომ არყის სმას სიცივის გამო დაეჩვია, როგორც მე და წუპაკა წებოთი კაიფს და ახლა იძულებულია ყოველდღე სვას, რადგან "ეშმაკი არ უსვენებს."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					and ran away, that it's been ten years since we've heard from my father, that she herself works as a salesperson in a cold kiosk, whose owner, an angry woman, is constantly accusing her of theft, but then, when they figure out nothing's been lost, doesn't even say she's sorry.  As if I'm also guilty for the fact that she's become a drunk, that she's become accustomed to drinking vodka because of the cold, just as Tsupaka and I get high on glue and now she's forced to drink every day, because "the devil gives her no peace."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთხელ მცემა.  მცემა სკამის ფეხით, რომელიც, ყოველი შემთხვევისათვის, კარსუკან გვქონდა მიყუდებული.  ისე მცემა, რომ წარბი გამისკდა და მარჯვენა ხელის ნეკა თითი მომტყდა.  კიდევ კარგი, ჩემს ყვირილზე მეზობლები შემოცვივდნენ და იმათ მიშველეს თორემ მომკლავდა, მაგრამ შინიდან ამისთვის არ წამოვსულვარ, სულ სხვა რამის გამო წამოვედი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Once, she beat me.  She beat me with the legs of a chair which we had standing up behind the door, just in case anything happened.  She beat me so badly my forehead split open, and the little finger of my right hand broke.  Thank God the neighbors ran in when I screamed, and helped me; otherwise she would have killed me. But I didn't leave home because I was afraid of this, I left for a completely different reason... </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვიცოდი ფულს სადაც ინახავდა და ის ფულიც წამოვიღე, წამოვიღე მისი საქორწინო ბეჭედიც, რადგან ვიცოდი რომ მამაჩემის ნაჩუქარი იყო. მაშინ დარწმუნებული ვიყავი, სწორად ვიქცეოდი, მაგრამ ახლა ვფიქრობ, რომ სისულელე ჩავიდინე -- რა ჩემი საქმე იყო.  თანაც მამაჩემი ამდენი ხანია აღარა ჩანს, იქნებ აღარც კი არის ცოცხალი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I knew where she kept her money, and I took that money, and I also took her wedding ring, because I knew that it was a gift from my father.  At that time I was convinced I'd done the right thing, but now I think that I committed something foolish -- it wasn't any of my business.  But at the same time, my father hasn't shown up for such a long time, maybe he's no longer alive.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ამის გახსენებაზე ახლაც სირცხვილის ოფლმა დამასხა.  ცოდად მოვიქეცი.  არა, შინიდან რომ წამოვედი არა ვნანობ, ის ფულისც, -- ოცდაათი ლარი -- რომ წამოვიღე არა უშავს, მაგრამ ბეჭდისთვის კი ხელი არ უნდა მეხლო...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At the thought of this, even now, a sweat of shame pours over me.  I acted badly.  No, I don't regret that I left because of fear, and even that I took the money -- thirty lari -- is no big deal, but I shouldn't have touched the ring...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ყუთიდან გამოვძვერი, თვალები მოვიფშვნიტე და საუზმის სამზადის შევუდექი:  ავიღე ალუმინის ჯამი, კოკა-კოლას წყლიანი ბოთლი, კიდევ ორი კვერცხი და ასანთი, რომლებიც ბუშლატის ჯიბეებში ჩავილაგე და მაღლა ავედი.  იქ, ორ აგურს შორის ცეცხლი გავაჩაღე, მერე ჯამში წყალი ჩავასხი, შიგ კვერცხები ჩავალაგე და ზედ შემოვდგი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I crawled out of the box, rubbed my eyes, and started fixing my breakfast:  I took the aluminium bowl, a Coca-Cola bottle for water, then two eggs, and a match, all of which I put in my pea-coat pockets, and went up.  There, I lit the fire between the two bricks, then poured the water into the bowl, put the eggs in, and set it on top.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ძალიან მიყვარს დილის ეს ჩირთი-ფირთი.  ამ დროს ქა--</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I really like these morning activities.  At that time,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					260</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					260</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ლაქში სიჩუმეა, კანტიკუნტად ისმის მანქანების ხმა, ჭადრებზე ბეღურები ჟივჟივებენ, რადგან მათაც სცივათ.  ზოგჯერ ქუჩაში გამოჩნდება სიცივისაგან აბუზული გამვლელი, რომელიც ჩემს სანახვაზე გაჩერდება და გაკვირვებული მიყურებს.  მე ყურადღებას არ ვაქცევ, ჩემთვის ვსაქმიანობ, ცეცხლს ნაფოტებს ვუმატებ და ისიც მალევე წავა, ნაბიჯს აუჩქარებს და თვალს მიეფარება.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					it's quiet in the city, the sound of the cars is heard here and there, the sparrows are chirping in the plane trees, because they're cold.  Sometimes, when I'm all hunched up from the cold, someone will walk by me on the street, stop when he sees me, and stare at me in amazement.  I don't pay any attention, carry on with my business, add chips to the fire, and he'll leave very soon, hurry his steps, and disappear.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					იქიდან რომ წამოვედით, მამა სოხუმის საავადმყოფოში იწვა, ინფარქტი ჰქონდა და ექიმები ამბობდნენ, ამისი ადგილიდან დაძვრა არ შეიძლებაო.  ბებია თავზე ადგა.  მაშინ მე ექვსი წლისა ვიყავი, მაგრამ დედ-მამის ლაპარაკი მაინც კარგად მახსოვს:  მამა დაჟინებით მოითხოვდა, რომ მე და დედა ქალაქიდან წავსულიყავით, დედას კი მამის მიტოვება არ უნდოდა.  ბოლოს მამაჩემი ისე გაბრაზდა, რომ ცუდად გახდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When we left there, my father was in a Sukhumi hospital; he'd had a heart attack and the doctors said he shouldn't be moved from his place.  My grandmother was taking care of him.  At that time I was was six, but I still remember my parents' conversation very well:  my fatehr was insisting that my mother and I leave the city, but my mother didn't want to leave my father.  In the end, my father got so angry, he became ill.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ქალაქში განუწყვეტლივ ისროდნენ, მაგრამ ბორია ბიძიამ, ჩვენმა ტყვარჩელელმა მეზობელმა, თავის "ნოლ-ექვსში" ჩაგვსხა და სოხუმიდან გაგვიყვანა.  მერე სხვებთან ერთად ფეხით მოვდიოდით.  უღელტეხილზე გაგვითოვდა.  ხალხი გზადაგზა ეცემოდა და იხოცებოდა, განსაკუთრებით მოხუცები და ძუძუთა ბავშვები.  ჩვენ გადავრჩით და ახლა აქა ვართ, ოღონდ ცალ-ცალკე, ის თავისთვის, მე -- ჩემთვის.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					They were constantly shooting in the city, but my uncle Boria, our Tq'varcheli neighbor, sat us in his "06" and took us out of Sukhumi.  Then, with others, we went on foot.  It snowed on us in the pass.  The people were falling along the way, and dying, especially the old people and nursing infants.  We survivied and now we're here, but on our own, she by herself, and I -- by myself.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჯამი ცეცხლიდან გადმოვდგი, წყალი გადავწურე, მოხარშული კვერცხები სარდაფში ჩავიტანე და გაზეთგადაფარებულ ყუთზე დავალაგე.  ისევ ის ბეჭედი მედგა თვალწინ და უეცრად გავიფიქრე, რა იქნება, რომ ავდგე და მამის მოსაძებნად წავიდე-მეთქი.  ამ აზრმა ისე ამაგდო, ხელები ამიცახცახდა და მეორე კვერცხი ვეღარ გავფცქვენი -- ეგეთი ფეთიანი ვარ, ყველაფერზე ეგრე ვიცი გაგიჟება.  ჭამის დროს სულ გამგზავრებაზე ვფიქრობდი და გული გამალებით მიცემდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I took the bowl off the fire, poured off the water, carried the boiled eggs into the basement and put them on a box covered in newspaper. Again, that ring is standing in front of my eyes, and suddenly I thought, what would happen, if I got up and went in search of my father.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საუზმეს რომ მოვრჩი, "მაგიდა" არ ამილაგებია, სამალავში ხელი შევყავი და იქიდან ქაღალდში გახვეული ფული და ოქროს ბეჭედი გამოვიღე.  ბეჭედი ისევ ქაღალდში შევახვიე და ჯიბეში ჩავიდე, ფული კი დავთვალე -- ოცდაშვიდი </p>
				</div>
				<div class="col-lg-4 english">
					<p>
					This thought made me so excited, that my hands were shaking and I couldn't peel the second egg -- I that kind of excitable person, I get so crazy about everthing.  While I was eating I was constantly thinking about the trip, and my heart was beating fast.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					261</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When I'd finished breakfast, I cleaned the "table," put my hand in the hiding place and took out the money and the gold ring wrapped in paper.  I wrapped up the ring again in the paper, and put it in my pocket, and I counted the money -- twenty-seven lari ["how much in 2014 $$?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ლარი გამოვიდა.  ამ ფულით სადაც გინდა იქ წავიდოდი!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					261</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ავდექი და მივიხედ-მოვიხედე.  ღრმა სარდაფი იყო.  მიწის პირზე გამოჭრილი სარკმელიდან დილის შუქი შემოდიოდა და იქაურობას ოდნავ ანათებდა.  აქ არავის შევუწუხებივარ.  მართალია, სულ ორი კვირა ვიცხოვრე, მაგრამ ისე შევეჩვიე, რომ უკვე მენანებოდა მისი მეტოვება.  ვიფიქრე, საბანს მაინც წავიღებ-მეთქი, მაგრამ სად უნდა მეთრია, დამეკარგებოდა ან ვინმე წამართმევდა გზაში, სულ ახალი სამანი იყო.  ახლაღა მივხვდი, რომ მართლა მივდიოდი და დავმშვიდდი, აღარც ხელები მიკანკალებდა და არაფერი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					With this money, you could go anywhere you wanted!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გადავწყვიტე გოშკა მენახა, იმან ყველაფერი იცოდა, ალბათ ისიც, ტყვარჩელში როგორ უნდა ჩავსულიყავი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I got up and looked all around.  The basement was deep.  From a window cut out at ground level, morning light came in and barely lit up the surroundings.  No one has bothered me here. It's true, I've lived here only two weeks, but I've gotten so accustomed to it that I'm already feeling sad to leave it.  I thought, at least I'll take my blanket, but how could I carry it? I might lose it, or someone might take it on the road -- it was an absolutely new blanket.  Just now, I realized that I'm really going, and I calmed down, my hands no longer were shaking at all.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნუ ბლიად," მითხრა გოშკამ, "ნუ ტი დაიოშ! მერე აბხაზებმა რომ დაგიჭირონ და გაგჟიმონ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I decided to go see Goshka.  He knew everything, maybe even how I could get to Tq'varcheli.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რათ უნდა დამიჭირონ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Oh wow!," ["Goshka sprinkles his speech with Russian, usually transliterated into Georgian, sometimes as a kind of slang:  ნუ ბლიად;ну бляд"] -- Goshka said to me, "You're not kidding!" ["More Russian for slang: ნუ ტი დაიოშ Ну ты даешь"] And what if the Abkhazians catch you, and kill you?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"როგორ რათ, ქართველი ხარ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Why would they kill me?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო, მერე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Whadda ya' mean, why, you're Georgian, right?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მერე, მაგათ ქართველები არ ევასებათ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yeah, so?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რა ეცოდინებათ რო ქართველი ვარ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"So, they don't like Georgians."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"როგორ, რა...რუსულად ლაპარაკობ? არა.  აბხაზურად? არც აბხახურად.  ზნაჩიტ ქართველი ხარ!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How will they know I'm Georgian?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მართალს ამბობდა.  ამაზე არც მიფიქრია.  კარგი, დავუშვათ მე არავის არაფერს ვკითხავ, მაგრამ თვითონ რო მკითხონ?  თუმცა, რა ვიცი, მე ვის რაში ვჭირდები?  არა რაღაც უნდა მოვიფიქრო...სანამ იქ ვცხოვრობდით, რუსული და ქართული თითქმის ერთნაირად ვიცოდი, მაგრამ თბილისში დამავიწყდა -- აქ ყველა ქართულად ლაპარაკობს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How, well... do you speak Russian?  No.  Abkhazian?  Not Abkhazian either.  That means,["More Russian sprinkled in: ზნაჩიტ значит"] you're Georgian."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ე, მაიცა," მეუბნება გოშკა, "ვითომ მუნჯი ხარ -- ნემოი.  ანი ბუდუტ სპრაშივატ ა ტი რუკამე, ხელებით, გაიგე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He was right.  I hadn't even thought about this.  Ok, for example, I won't ask anybody anything, but what if they ask me?  It turns out, what do I know, what am I going to need?  No I need to think of something.  While we were living there, I knew Russian and Georgian almost equally, but I've forgotten in Tbilisi -- here everyone speaks Georgian.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მართლა გენიოსია ეს გოშკა, არა და ჩემზე ერთი წლით არი დიდი, მეტით კი არა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Hey, you can wave," Goshka said to me,"as if you're deaf and dumb. They'll ask you, and you answer with your hands, arms, get it?"[Here he mixes Georgian and Russian, though not slang: ანი ბუდუტ სპრაშივატ ა ტი რუკამი, ხელებით, გაიგე? Они будут спрашивать а ты руками, хелебит, гаиге?]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"იქამდე როგორ უნდა ჩავიდე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He's really a genius, that Goshka is, and he's not more than a year older than me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"როგორ? კარგაც. ფული გაქ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How can I get there?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					262</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Wow!  It's easy.  Do you have money?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მაქ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					262</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მატარებლით.  ბილეთი რვა ლარია, თუ ლტოლვილის საბუთი გაქ -- ოთხი და ჩახვალ ზუგდიდში, იქიდან ავტობუსით ენგურამდე, მერე ფეხით ჩერეზ მოსტ და მერე კიდევ ავტობუსით დო ოჩამჩირა..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yep."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"იქ ავტობუსი დადის?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"By train.  A ticket costs 8 lari. If you have a refugee ID -- it's four, and you'll get to Zugdidi, from there by bus to Enguri, then on foot across the bridge ["More Russian mixed in with Georgian:  ჩერეზ მოსტ через мост"] "and then further by bus, till ["Again, Russian mixed ing: დო до"] Ochamchire..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"დადის"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Does the bus go there?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"და იქიდან?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes, it does."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"წინათ ელეკტრიჩკა იყო, ეხლა არ ვიცი..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And from there?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ელექტრიჩკა" რომ იყო, მეც კარგად მახსოვს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"There used to be an "electric commuter train," ["The term is borrowed from Russian, transliterated: ელეკტრიჩკა электричка"] but now I don't know..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ფეხით?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Even I well remember it well when the "electric commuter train" was there.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"არა, ფეხით შორს არი... მაგრამ თუ ფეხით, მაშინ პო შპალამ... რელსებს წაყვები, გაიგე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"By foot?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"No, it's too far by foot.. but if you go by foot, then along ["More Russian: პო по"] the railroad ties... follow the rails, got it?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მომე ეხლა ორი ლარი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yep."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რათა?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Now give me two lari."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვა, ხო გასწავლე!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What for?!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ამოვიღე და ლარი მივეცი.  შემეძლო სულაც არ მიმეცა.  პატარაა, გაფსხლიკული, ძალით ვერ წამართმევდა, მაგრამ ეკუთვნოდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Well, I taught you!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჯიბეში ისე ჩაიდო, არ გაუპროტესტებია, მაგრამ არც მადლობა უთქვამს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I took out one lari, and gave it to him.  I could've not given him anything. He's small and scrawny, he couldn't have taken it by force, but he deserves it.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"კარგი, წავედი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He puts it in his pocket, he doesn't protest, but he doesn't say thanks, either.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"დავაი... ნი პუხა, ნი პერა!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"OK, I'm off."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საღამოს ვიყიდე "კილკის" ორი კონსერვი, ორი პური და ნახევარი კილო ხალვა.  ეს ყველაფერი ჩემს ძველ ზურგჩანთაში ჩავალაგე და ვაგზალში გავედი.  ლტოლვილის საბუთი, რა თქმა უნდა, არ მქონდა, ამიტომ ბილეთში რვა ლარი გადვიხადე და საერთო ვაგონში ავედი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"So long, break a leg!" ["Here Goshka uses a Russian idiom:  დავაი...ნი პუხა, ნი პერა!  давай... ни пуха, ни пера!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უბრალოდ ხდებოდა, ძალიან უბრალოდ ხდებოდა ყველაფერი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the evening I bought a tin of sardines, two loaves of bread, and half a kilo of halva.  I put everything in my old backpack, and went to the train station.  Of course, I don't have a refugee's ID, so I paid eight lari for a ticket, and got in a third class wagon.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აი, მატარებელი დაიძრა და უკან დარჩა სადგურის შენობა და სველი ბაქანი, მერე თანდათანობით მოუმატა სიჩქა-</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Everything happened very, very simply.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					263</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					And so, the train set off, and the station building and the damp platform remained  behind, then gradually it gathered speed.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რეს, ვაგონის ფანჯრიდან გამოჩნდა მაღალი, ნაცრისფერი სახლები, რაღაც ძველი, გაუქმებული ქარხანა თუ საწყობი, რომლის ეზოშიც იდგა ერთ დროს ყვითელი, ახლა კი ჟანგისაგან შეჭმული ტრაქტორი, იქვე ეყარა მილები, შპალები, რელსები.  ეს ყველაფერი ნელა, თითქმის უხმაუროდ მისრიალებდა უკან.  ახლა გამოჩნდა გრძლად გაჭიმული ქუჩა, ტროტუარის გასწვრივ ჩარიგებული სავაჭრო ჯიხურები, იქვე ახლოს -- მარტოხელა, მშიერი ძაღლი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					263</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მატარებელმა სიჩქარეს მოუმატა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					From the wagon window appeared tall, ash-colored houses, some kind of old, abandoned factory or storage building, in whose courtyard stood a tractor, once yellow, but now eaten away by rust, and pipes, ties, rails all thrown around. Everything was moving slowly, as if sliding backwards without a sound.  Now a road appeared, stretching out in the distance; kiosks were lined up along the pavement, and there, close by, a lonely, hungry dog...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რა შიში, რის შიში, პირიქით, მიხარია -- მე ხომ იმას ვაკეთებ, რაც სხვამ ვერავინ შეძლო, ვერ გაბედა, მე კი გადავწყვიტე და აი, უკვე მივდივარ!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The train gathered speed...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ნეტა წუპაკა ცოცხალი ყოფილიყო, ისიც ხო წამოვიდოდა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Why should I be afraid, what should I be afraid of -- the opposite, I was happy -- after all, I was doing what no one else could do, would dare to to, but I'd made up my mind, and was already on my way!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ოჩამჩირემდე ერთად ვივლიდით, იქიდან ის გზას სოხუმისკენ გააგრძელებდა, მე კი ტყვარჩელში დავუბერავდი.  ახლაც მახსოვს ტყვარჩელის სადგურის ბაქანი, მოასფალტებული და რატომღაც სველი... ალბათ, წვიმს... ხო, წვიმს -- ბაქანზე წყლის გუბეები დგას... ჩვენი სადარბაზოელი აფხაზის გოგო ლიდა, სადგურის რეპროდუქტორში რაღაცას აცხადებს -- ჯერ აფხაზურად, მერე ქართულად და ბოლოს რუსულად.  დედას ჩემი ხელი უჭირავს ხელში.  მამა სადგურის შენობიდან გამოდის, აბოლებულ სიგარტს მუჭში მალავს, რომ წვიმამ არ დაუსველოს, მეორე ხელს კი შორიდან გვიქნევს.  ეტყობა, სოხუმში მივდივართ და მამამ "ელექტრიჩკის" ბილეთები იყიდა.  ბაქნიდან მოჩანს "გრესის" საკვამლე მილები, მარცხნივ -- ტყით შემოსილი მთები და მწვანეში ჩაფლული წითელკრამიტიანი სახლები.  ალბათ, გაზაფხულია ან ზამთრის პირი, იმიტომაც აცვია მამას თავისი ლურჯი ქურთუკი, თავზე კი ღია ფერის კეპი ახურავს.  ჩემი მშობლები "გრესში" მუშაობენ.  მამა ორთქლის ტურბინის მემანქანეა, -- დედა -- წყალსაქაჩის ოპერატორი.  "გრესის ბინებში" ოთხსართულიანი სახლის პირველ სართულზე ვცხოვრობთ, მე</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					If only Tsupaka were alive, he would've come, too...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					264</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We would travel together to Ochamchire, and from there he would continue to Sukhumi, and I'd take off for Tq'varcheli.  Even now, I remember the Tq'varcheli station platform, made of asphalt, and somehow wet...maybe it's raining... yes, it is raining -- puddles of water stand on the platform... Lida, an Abkhazian girl from our apartment complex, is announcing something or another on the station loudspeaker -- first in Abkhazian, then in Georgian, and finally in Russian.  My mother is holding my hand in hers.  My father is coming out of the station building, hiding a smoking cigarette in his fist so the rain doesn't get it wet, and with his other hand he waves to us from a distance.   Apparently, we're going to Sukhumi, and my father was buying tickets for the "electric commuter train."  From the platform you can see the smokestackes of the "Gresi" plant, on the left -- the mountains covered with forests, and readtiled housed buried in the greenery. Probably, it's spring, or the end of winter, and because it's cold, my father is wearing his blue jacket, and on his head, a light colored cap.  My parents work at "Gresi."  My father is the mechanic at the Ortkali turbine, -- and my mother -- the operator of the waterworks.  We live in a four-rooom apartment on the first floor of the "Gresi apartments," I'm</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჯერ სკოლაში არ დავდივარ, მაგრამ მალე წავალ.  დედა და მამა სხვადასხვა ცვლაში მუშაობენ, ამიტომ ხან ერთია შინ, ხანაც -- მეორე.  ზოგჯერ ისეც ხდება, რომ ორივენი შინ არიან და თუ ეს დღე შაბათი ან კვირაა, მაშინ სამივენი სოხუმში მივდივართ  ზაფხულობით თითქმის მთელ დღეს კელასურში, ზღვის პირას ვატარებთ -- ვბანაობთ, მზეს ვეფიცხებით.  როცა მოგვშივდება, ვყიდულობთ გემრიელ "ჩებურეკებს" და იქვე, პლაჟზევე შევექცევით.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					264</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზამთრობით ქალაქში ვსეირნობთ.  შევდივვართ კინოში, მაღაზიებში, მერე მივდივართ ზღვისპირა რესტორანში, რომელსაც "დიოსკურია" ჰქვია და მამა ოფიციანტს მწვადებს და ერთ ბოთლ ღვინოს უკვეთავს.  იქ კარგა ხანს ვსხედვართ, ისმის მუსიკის ხმა, ჩემი მშობლები წყნარად საუბრობენ, მე კი ფანჯრიდან ვუყურებ აღელვებულ ზღვას, თოლიებს და თეთრ სეირნერს, რომელიც თუხთუხით მიაპობს ტალღებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					not going to school yet, but I will soon.  My mother and father work different shifts, so they take turns being home.  Sometimes it happens that both of them are home, and if it's Saturday or Sunday, then all three of us go to Sukhumi.  In the summer, we'd spend almost all day in Kelasuri, on the edge of the sea -- we'd bathe, lie in the sun.  When we got hungry, we'd buy delicious "chebureki" ["lamb dumplings"] and eat them right there, on the beach.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რესტორნიდან გამოსულები ნელა მივსეირნობთ თეატრის მიმართულებით და იქ უსათუოდ შევდივართ ერთ პატარა, მყუდრო კაფეში, სადაც ჩემი დედ-მამა სვამს ყავას, მე კი ლიმონათით ვიჭყიპები.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In winter, we'd walk in the city.  We go to the cinema, to the stores, then we'd go to a restaurant by the shore, called "Dioscuri" and my father would order "mtsvadi" ["BBQ"] and a bottle of wine.  We'd sit there for a long time, you could hear music, my parents would talk peacefully, and I would look through the window at the turbulent sea, the seagulls and the white seiner fishing boat, chugging and cutting through the waves. </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საღამოს შინ ვბრუნდებით.  მე, როგორც წესი, გზაში მძინავს და მაშინღა ვიღვიძებ, როცა უკვე ტყვარჩელში შევდივართ.  ვაგონის ფანჯრიდან თვალებისფშვნეტით ვიყურები და გაკვირვებული ვხედავ ჩვენს ბაქანს, ჩვენი სადგურის ლურჯად შეღებილ შენობას და წარწერას აფხაზურ, ქართულ და რუსულ ენებზე.  კითხვა უკვე ვიცი და ამიტომ ხმამაღლა ვმარცვლავ: -- "ტყვა-რჩე-ლი" თან მიკვირს, რომ ასე უცებ ჩამოვედით.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Leaving the restaurant we'd walk slowly in the direction of the theatre, and there, inevitably, we'd go into a small, cozy cafe, where my mom and dad drank coffee, and I'd fill up on lemonade.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ეს ჩემი მატარებელი კი თავაწყვეტილი მიქრის, ბორბლებს რელსებზე რაკა-რუკი გაუდით.  ფანჯრიდან მოჩანს რკინისგზის გასწვრივ ჩარიგებული მაღალი ძაბვის ანძები და ტელეგრაფის ბოძები.  ბოძებზე გაბმული მავთულები აიწევენ მაღლა, ავლენ, ავლენ და მერე ისევ დაბლა ეშვებიან.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the evening, we'd return home.  As a rule, I'd sleep on the way, and wake up right then, whey we're already in Tq'varcheli.  From the wagon window, rubbing my eyes, I would look, and amazed, see our platform, our blue building, and the sign in Abkhzian, Georgian, and Russian.  I already knew how to read, and would break into syllables:  "Tq'va-rche-li!" and at the same time was amazed that we've arrived so quickly.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დილით მგზავრების ჩოჩქოლმა და ხმაურმა გამაღვიძა</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					But now, my train is rushing headlong, the wheels rattling on the rails.  Through the window appear the  tall electric stakes and the telegraph wires, stretching across the railroad.  On the poles, the wires, stretched out, rise up high, rise up and up, and then dip down again.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					265</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the morning the commotion and noise of the travelers wakes me up -- </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მატარებელი ზუგდიდის სადგურში შედიოდა.  ეს რომ გავიგე, გულმა გამალებით დამიწყო ძგერა.  მატარებელი ჯერ არ გაჩერებულიყო, მაგრამ ხალხი უკვე გასასვლელისკენ მიდიოდა, ვაგონის კართან გრძელი რიგი გამართულიყო და მეც იმ რიგში ჩავდექი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					265</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მაშინ სახლიდან ახალი წამოსული ვიყავი.  ჯერ ისევ სექტემბერი იდგა, ღამ-ღამობით თბილოდა და ამიტომ პრობლემა არ იყო -- გრიბოედოვის თეატრის უკან, კოწახურის ბუჩქებქვეშ ვიძინებდი. ერთ დილით გამეღვიძა და ვიგრძენი, რომ ვიღაც მიყურებდა, ან შეიძლება იმიტომ გამეღვიძა, რომ ვიღაც მიყურებდა.  ერთი სიტყვით, გამეღვიძა.  თვალები გავახილე და დავინახე კაცი, რომელიც ბუჩქების წინ ჩაცუცქულიყო და ჩუმად მათვალიერებდა.  მე ჯერ პოლიციელი მეგონა, შემეშინდა, მაგრამ ფორმა არ ეცვა და ცოტა დავმშვიდდი.  გამოვძვერი და ის იყო, წასვლა დავაპირე, რომ გამაჩერა და მეობნება, რა გქვიაო.  მაგის ჩიტი ვიყავი, ნამდვილი სახელი მეთქვა? -- მამუკ-მეთქი. მერე აქ რატო გძინავს, სახლი არა გაქვსო?  არა-მეთქი, სახლი რომ მქონდეს, ქუჩაში რატო დავიძინებდი-მეთქი.  რაო, ლტოლვილი ხარო?  ხო-მეთქი.  მშობლებიო?  მშობლები სუხუმის დაბომბვის დროს დამეხოცა-მეთქი.  წამოდი, წამოდიო!  ჩამკიდა ხელი და მივყავარ.  ქვის კიბე ჩამოვიარეთ და მეტროს სადგურთან გამოვედით.  სულ იოლად გავექცევი -- გამოვტაცებ ხელს და გავვარდები, რას დამეწევა, ბებერია, ერთი ორმოცდაათი წლისა მაინც იქნება, მაგრამ მაინტერესებს სად მივყავარ და ამიტომ მორჩილად მივდევ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					the train has pulled into the Zugdidi station.  When I realize this, my heart begins to beat faster.  The train hasn't stopped yet, but the people are already heading towards the exit, a long line has formed by the wagon door, and I, too, stand in that line...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჩავედით მეტროში, ვაგონში შევედით და მესამე გაჩერებაზე ჩამოვედით.  არ ვიცი სად მივყავარ, იქნებ უპატრონო ბავშვთა სახლში, ან პოლიციაში, მაგრამ არ მეშინია, რადგან ვიცი, რომ ბოლო მომენტში მაინც ნაღდად გავექცევი.  მეტროდან რომ ამოვედით იქვე, მარჯანიშვილზე აუხვია.  ხელს არ მიშვებს, მაგრად ვუჭერივარ, ეტყობა, ხვდება, რომ თუ მოვინდომე, ადვილად გავექცევი.  ერთ ეზოში რომ შევე</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At that time, I had just left home.  It was still September, the evenings were warm, so there was no problem -- I slept beneath some berberis bushes behind Griboedov Theatre.  One morning I woke up and felt that someone was watching me, or perhaps I woke up, because someone was watching me.  Either way, I woke up.  I opened my eyes, and I saw a man who was crouched in front of the bushes, watching me in silence.  At first I thought he was a policeman, but he wasn't wearing a uniform and I calmed down a little.  I climbed out, and was just about to head off, when he stopped me and said to me, "What's your name?"  I wasn't so stupid ["He uses a Georgian idiom:  "Was I his bird?""] as to give him my real name. "Mamuka," I said.  "Then why are you sleeping here, don't you have a home?"  "No," I said, "if I had a home, why would I be sleeping on the street?" "What then," he said, "are you a refugee?" "Yeah." I said. "Parents?"  "My parents died during the bombing of Sukhumi." I said.  "Come, come on!"  He grabbed my hand and led me away.  We went down a stone stairwell and came out by the metro station. I could easily run away -- he pulled my hand, but I could take off, and how could he catch me, he's an old man, he may be 50 years old, but I'm interested to see where he's taking me, and so I went obediently.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					266</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We went down into the metro, entered a car, and got out at the third stop.  I didn't know where he was taking me, maybe to an orphanage, or to the police, but I wasn't afraid because I knew that still, at the last moment for sure, I could run away.  When we left the metro, right there, he turned up Marjanishvili Ave.  He didn't let go of my arm, but was holding me, as if he understood that if I wanted to, I could easily run away.  When we entered a courtyard,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დით, მაშინღა ვეკითხები, სად მივდივართ-მეთქი.  ჩემთანო. თქვენთან რა მინდა-მეთქი.  როგორ, რა -- გაჭმევ, გასმევ, დაგბან, თბილ ლოგინში დაგაძინებო.  მე გამახსენდა ვიღაცვიღაცეების ნალაპარაკევი გაფუჭებულ კაცებზე და პატარა ბიჭებზე, მაშინვე ხელი გამოვტაცე და გამოვიქეცი.  სანამ ჭიშკარში გავვარდებოდი უკან მივიხედე და დავინახე, რომ შუა ეზოში იდგა და დაბნეული, რაღაცნაირად გულდაწყვეტილი მიყურებდა.  ახლა რომ ვუფიქრდები, იქნებ არც ისეთი გაფუჭებული კაცი იყო, მაგრამ რა ვიცი, სანდო არავინ არი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					266</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სადგურში ენგურისკენ მიმავალი ავტობუსი ვიკითხე.  ერთ "პაზიკზე" მანიშნეს, ეგ არიო.  მივედი და შოფერს დავებაზრე, შეიძლება ენგურამდე გამოგყვე-მეთქი?  სად მიდიხარო, გალში, ბებიასთან-მეთქი.  წამოდიო.  ავტობუსში ავედი და სულ უკანა სკამზე დავჯექი.  მალე "პაზიკი" ხალხით გაივსო, გასასვლელი კალათებითა და ჭრელი მაფრაშებით ჩაიხერგა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					right away I asked, "Where are we going?" "To my place," he said. "Why do I want to go to your place?"  "What do you mean, why -- I'll feed you, give you something to drink, bathe you, let you sleep in a warm bed."  I remembered some people talking about depraved men and small boys, and I immediately broke my arm free and ran away.  When I'd run through the gates, I looked back and saw that he was standing in the middle of the courtyard, lost, looking at me somehow sadly.  When I think about him now, maybe he wasn't such a depraved man, but what do I know, no one is trustworthy.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დიდხანს აღარ გავჩერებულვართ, შოფერმა ავტობუსი დაქოქა და დავიძარით.  აქეთ უფრო თბილოდა, მაგრამ ნესტი იდგა.  აზრზე არ ვიყავი, ამაღამ სად უნდა დამეძინა და, ნეტა ჩემი საბანი წამომეღო-მეთქი.  ვინანე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At the station I asked about a bus going to Enguri.  They pointed to a "Pasic," "there it is," they said.  I went and asked the driver, "Is it possible for you to take me to Enguri?" "Where are you going?" he asked. "To Gali, to my grandmother's," I said.  "Come on." I got in the bus and sat down in the very last seat.  The "Pasic" was soon filled with people, and the entrance was blocked with baskets and multi-colored bags.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მანქანა დანგრეული გზაზე მიჯაყჯაყებდა, გულ-მუცელი სულ ერთიანად ამეთქვიფა, ერთი-ორჯერ თავიც კი მიმარტყმევინა შუშაზე. სხვებიც ჩემს დღეში იყვნენ, მაგრამ ხმას არავინ იღებდა, უკმაყოფილებას არავინ ამოთქვამდა, ეტყობა, შეჩვეულები იყვნენ ასეთ მგზავრობას...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We didn't wait very long, the driver turned on the bus and we started to move.  It was warmer here, but damp.  I had no idea where I would sleep tonight, and I wished I'd brought my blanket.  I regretted not having it.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზოგჯერ უხიაგი ფიქრი გამიელვებდა -- უკან ხო არ დავბრუნდე-მეთქი, მაგრამ ამ აზრს მაშინვე თავიდან ვიშორებდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					 The car bounced over potholes in the road, my stomach and heart were whipped up together, and once or twice my head hit the window.  The others were in my same situation, but no one said a word. No one mentioned any dissatisfaction, it seemed they were accustomed to this kind of traveling...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზაფხულობით, ტყვარჩელში, ბიჭები მდინარეზე დავდიოდით საბანაოდ.  სულ ახლოს იყო, მაგრამ დედა მაინც მიშლიდა იქ სიარულს.  ეშინოდა, რომ "ალიკას კლდიდან" გადმოვხტებოდი.   მან არ იცოდა, რომ იმ კლდიდან გადმოხტომა არც ისეთი იოლი საქმე იყო.  ჩემხელები იქიდან არც ხტებოდნენ, ათი-თორმეტი წლისა მაინც უნდა გამხდარიყავი, რომ</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Sometimes a stubborn thought flashed in my mind -- "I should go back," but I immediately pushed this thought away.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					267</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the summers, in Tq'varcheli, we boys used to go to the river to bathe.  It was very close by, but my mother still forbade me from going there.  She was afraid I would jump from "Alika's cliff."  She didn't know it wasn't so easy to jump from that cliff.  Boys my age did not jump from there, you had to be at least 10-12 years old, for</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უფროს ბიჭებს ამისი უფლება მოეცათ, მე კი მაშინ ჯერ შვიდისაც არ ვიყავი და ამიტომ ჩემს ტოლებთან ერთად ქვემოთ თავთხელ წყალში ვჭყუმპალაობდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					267</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კლდე მდინარეს ზემოდან დაჰყურებდა, მის ძირში კი ღრმა მორევი ტრიალებდა. კლდის ქიმამდე ბილიკი ადიოდა.  წინათ იქიდან ვიღაც აფხაზის ბიჭი, ალიკა გადმომხტარიყო, კლდის შვერილზე კეფა ჩამოერტყა და მომკვდარიყო.  მიუხედავად ამისა, იქიდან მაინც ხტებოდნენ -- ტიტლიკანა ბიჭები ფრიალო ბილიკით კლდეზე ადიოდნენ, გზადაგზა ჯაგრცხილის და თხილის ბუჩქებს ებღაუჭებოდნენ და კლდის ქიმზე გასულები ფარული შიშით იყურებოდნენ ქვემოთ, აქა ფებული მორევისაკენ.  ზოგი უფრო გამბედავი და გამოცდილი ასვლისთანავე ხტებოდა, ზოგი კი გადმოსახტომად საათობით ემზადებოდა ხოლმე, მაგრამ არ მახსოვს, იქ ასული ბიჭი უკან იმავე გზით ჩამოსულიყოს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					the older boys to give you the right, and at that time I wasn't even 7, and so I splashed around with the boys my age in the shallow water beneath the cliff.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ახლა მეც ასე ვიყავი.  მეჩვენებოდა, რომ იმ კლდის თავზე ვიდექი და გადმოსახტომად ვემზადებოდი.  ჯერ კიდევ შეიძლებოდა ქვემოთ ჩამოსვლა, ჯერ კიდევ მქონდა დრო, კარგად ამეწონ-დამეწონა ყველაფერი და თუ საჭიროდ ჩავთვლიდი, უკანაც დავბრუნებულიყავი, მაგრამ ამგვარი ფიქრი საშინელ სირცხვილად მიმაჩნდა და ამიტომ მაშინვე თავიდან ვიშორებდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					From the top of the cliff you could see down to the river, and at its base swirled a deep eddy. A path led up to the top of the cliff.  Earlier, an Abkhazian boy, Alika, had jumped from there, hit the back of his neck on a bulge in the cliff, and had died.  In spite of this, they still jumped from there -- naked boys would go up the steep path, along the way grabbing on to the oriental hornbeam and hazel nut bushes, and once they had reached the top of the cliff, hiding fear they looked down, towards the foaming whirlpool.  Some of the braver and more experienced ones jumped as soon as they got to the top, and others would spend hours getting ready to jump, but I don't remember that any boy who'd gone there had come back down along the same path.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ავტობუსი სველ, ნაწვიმარ გზაზე მიჯაყჯაყებდა.  მინები დაორთქილილიყო, მაგრამ ხელს თუ გადაუსვამდი, გამოჩნდებოდა ვრცელი ნასიმინდარი, იმის იქით ჭანჭრობი და უფრო იქით -- ფოტოლგაცვენილი ტყით შემოსილი გორები.  ზოგჯერ, გზის აქეთ-იქით მოჩანდა ორსართულიანი სახლები, კოინდარიანი ეზოები.  გზისპირებზე ძროხები იდგნენ, იცოხნებოდნენ და მოწყენილები გვიყურებდნენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Now, I, too, was like that.  It seemed to me that I stood on the edge of that clif and was getting ready to jump.  It was still possible to go back down, I still had time to weigh everything well, and if I thought is was necessary, I could have gone back, but such a thought seemed horribly shameful to me, and so I immediately pushed it out of my mind.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ენგურის ხიდამდე რამდენიმე ადამიანი თავისი ბარგი-ბარხანიანად ჩავიდა და ავტობუსი ცოტა შეხალვათდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The bus bounced along the wet, rain-covered road.  The windows had fogged up, but if I wiped them with my hand, I could see the vast cornfields, beyond that boggy meadowland, and further on -- the mountains covered in forests with their leaves fallen.  Sometimes, here and there along the road you could see two story houses, ryegrass courtyards.  On the edge of the road cows were standing, grazing and looking at us listlessly.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აქ ძირითადად ქალები და მოხუცები იყვნენ. მათი ლაპარაკიდან შევიტყვე, რომ ისინი გალის რაიონის სოფლებში</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Several people had gotten off with their luggage at the Enguri bridge, and the bus opened up a little bit.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					268</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					There were mainly women and old people.  From their conversation I learned that they lived in villages in the Gali region</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ცხოვრებდნენ, ზუგდიდის ბაზარში ქათმები, გოჭები, სულგუნი და აჯიკა გაეყიდათ.  იქვე შეეძინათ ფქვილი, შაქარი და სხვა საჭირო პროდუქტი და ახლა შინ ბრუნდებოდნენ.  ძირითადად მეგრულად ლაპარაკობდნენ, რომელიც მე არ მესმოდა, მაგრამ ზოგჯერ ქართულსაც გამოურევდნენ ხოლმე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					268</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რა თქმა უნდა, მე ის მაინტერესებდა რა მდგომარეობა იყო ხიდგაღმა, საშვი ან რაიმე საბუთი ხომ არ უნდა წარგვედგინა აფხაზი მესაზღვრეებისათვის, მაგრამ ამაზე კრინტსაც არავინ ძრავდა და მეც არავის არაფერს ვეკითხებოდა, რადგან მეშინოდა არ შეეტყოთ, რომ გალში კი არა, ოჩამჩირეში და, უფრო იქითაც, ტყვარჩელში ვაპირებდი გადასვლას.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					and were selling chickens, piglets, "sulguni" cheese and "adjika" sauce at the Zugdidi market. There, they had acquired flour, sugar and other necessary items and were now returning home.  For the most part, they were speaking Mingrelian, which I didn't understand, but sometimes they would mix in Georgian.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თბილისში აფხაზ ბოევიკებზე საშინელი ამბები დადიოდა:  ყვებოდნენ, როგორ აწამებდნენ ისინი ქართველებს, როგორ აბუჩად იგდებდნენ და შეურაცხყოფას აყენებდნენ, როგორ ხვრეტდნენ.  ქართველების სისხლის სმასა და იმათი თავებით ფეხბურთის თამაშზე აღარაფერს ვიტყვი, რადგან, დარწმუნებული ვარ, ეს თქვენც არაერთხელ გსმენიათ.  რაც უფრო ვუახლოვდებოდით ენგურს, მით უფრო მეტად მიპყრობდა შიში.  არ ვიცოდი, რა მელოდა იქ, რა დამხვდებოდა და ამიტომ გული გამალებით მიცემდა.  ერთადერთ ნუგეშად ის მრჩებოდა, რომ ესენი, ეს მეგრელის ქალები და მოხუცები არხეინად იყვნენ, დინჯად საუბრობდნენ, ზოგჯერ ხუმრობდნენ კიდეც და ხმამაღლა იცინოდნენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Of course, I was interested in what the situation was on the other side of the bridge, whether or not we'd have to present a pass or document to the Abkhazian border-guards, but no one said a word about this, and I didn't ask anybody anything, becasue I was afraid they'd find out I was planning to go not only to Gali, and to Ochamchire, but beyond that, to Tq'varcheli.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლოს, როგორც იქნა, ავტობუსი გაჩერდა, ხალხი აყაყანდა, ჩანთებსა და მაფრაშებს წამოავლეს ხელი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In Tbilisi, there were frightening stories about Abkhazian irregular soldiers: people would talk about how they tortured Georgians, how they insulted and abused them, how they would shoot them.  I won't say anything about drinking Georgians' blood, or playing soccer with their heads, because I'm sure you've heard this more than once.  The closer we got to Enguri, the more fear took hold of me.  I didn't know what was waiting for me there, what would happen, and so my heart was beating fast.  The only consolation I still had was that the Mingrelian women and old people were without a care in the world, and were talking calmly, sometimes even making jokes and laughing out loud.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ავტობუსიდან ჩამოვედი თუ არა, მაშინვე ავტომატგადაკიდებული სამხედროები დავინახე, მაგრამ მივხვდი, რომ ესენი ქართველები იქნებოდნენ, რადგან ჩვენთვის არავითარი ყურადღება არ მოუქცევიათ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the end, finally, the bus stopped, the people were chattering loudly, and grabbed their bags and woven sacks.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საპალნეაკიდებული ხალხი ხიდისკენ დაიძრა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					As soon as I got out of the bus, I saw the soldiers with their machine guns, but I realized they were probably Georgian, because they didn't pay any attention to us.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მე ერთ დედაბერს ჩანთა გამოვართვი, მოგეხმარებით-მეთქი და მიუხედავად იმისა, რომ თავიდან ეჭვით ამათვალიერ-ჩამათვალიერა და ჩემი ჩაცმულობა აშკარად არ მოუვიდა</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The people, laden down with their luggage, moved towards the bridge.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					269</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I took one old woman's bag, and said, "Let me help you," and even though she looked me up and down with suspicion, and clearly didn't like the way I was dressed,</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თვალში, ჩანთა მაინც დამითმო და მეც, ზედმეტად რომ არ მეეჭვიანებინა, გვერდით გავყევი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					269</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მალე ხიდს მივუახლოვდით, სადაც რუსის სალდათები იდგნენ, მაგრამ არც იმათ გაუციათ ხმა, დაბარგულ ხალხს გულგრილად უყურებდნენ და ჩემთვის ხომ ზედაც არ შემოუხედავთ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					still, she handed her bag to me, and so as not to make her more suspicious, I followed by her side.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მერე ხიდი გადავიარეთ და ენგურის მეორე ნაპირზე გადავედით.  აქ კი შემეშინდა, რადგან დავინახე შეიარაღებული აფხაზები და ისიც შევნიშნე, რომ წინ მიმავალ მგზავებს აჩერებდნენ და საბუთებს უსინჯავდნენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Soon, we approached the bridge where the Russian soldiers were standing, but even they didn't say anything; indifferently, they watched the people carrying their baggage, and didn't even glance at me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მაგრამ დავფრთხი, დედაბერს შევხედე, ვიფიქრე, დავაგდებ ამ ჩანთას და უკანმოუხედავად მოვკურცხლავ-მეთქი, მაგრამ, თითქოს ჩემს ფიქრებს მიხვდაო, მან თავი დამიქნია და მშვიდად გამიღიმა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Then we crossed the bridge and crossed over to the other bank.  And here, I began to feel afraid, because I saw armed Abkhazians and I noticed they were stopping the travelers in front of me and checking their documents.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აფხაზ მესაზღვრეებს რომ მივადექით, დედაბერმა უბიდან რაღაც ქაღალდი ამოიღო და ერთ პირტიტველა ბიჭს მიაწოდა, რომელმაც საბუთი ყურადღებით გასინჯა, მერე მე გადმომხედა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					But I was frightened. I looked at the old lady, and thought, I'll drop this bag and run away without looking back I'll rush, but as if she guessed my thoughts, she nodded her head and smiled at me calmly.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ა ტი კუდა!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When we got to the Abkhazian border guards, the old woman took some kind of paper out of her chest pocket and handed it to a beardless boy, who examined the document carefully, then looked at me:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გულმა გამალებით დამიწყო ცემა, მაგრამ მაშინვე გოშკას დარიგება გამახსენდა და მუნჯურად ვანიშნე, ამ დედაბერთან ვარ-მეთქი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And where are you going?" ["The guard is speaking in Russian, transliterated into Georgian: ა ტი კუდა? А ты куда?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აფხაზი ახლა ჩემს დედაბერს მიაჩერდა, მაგრამ ის არ დაბნეულა და უთხრა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					My heart began to pound, but right away I remembered Goshka's advice and gesturing like someone deaf and dumb, let them know I'm with this old woman. </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვნუკ მოი, ვნუკ!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The Abkhazian now stared at my old woman, but he didn't say anything, and she said to him: </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ა ვნუკ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"He's my grandson, my grandson!" ["The following exchange is also in Russian, transliterated into Georgian: ვნუკ მოი, ვნუკ! Внук мой, внук!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"და ვნუკ!" მერე მე მომიბრუნდა, "მაიართი, წიე, აშო!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Ah, your grandson?" ["ა, ვნუკ? А, внук?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხმისამოუღებლად გავყევი.  მძიმე ჩანთას მივათრევდი და ვცდილობდი უკან არ მიმეხედა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes, my grandson." ["და, ვნუკ Да, внук."] Then she turned to me, "Come with me, boy, this way!" ["Here the old woman is speaking Mingrelian, transliterated into Georgian: მაიართი, წიე, აშო!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სამშვიდობოს რომ გავედით, დედაბერი მეუბნება:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I followed her without saying a word.  I was dragging the heavy bag, and trying not to look back.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვინ ხარ, ბიჭო, შენ, სად მიდიხარ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When we got to a safe place, the old woman said to me:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მადლიერების გრძნობით მივაჩერდი, ახლა ეს დედაბერი</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Who are you, boy, where are you going?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					270</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I stared at her with a feeling of gratitude; I now loved this old woman</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საკუთარ ბებიასავით მიყვარდა, გული ამომიჯდა, ყელში ხორკლიანი გორგალი მომაწვა და კინაღამ ღრიალი მოვრთე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					270</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"კაი, თუ არ გინდა ნუ მეტყვი..." მშვიდად მითხრა და გზა განაგრძო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					like my own grandmother. I felt like I was going to cry, like a rough ball of wool was pushing on my throat and I almost started to wail.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უკან ავედევნე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"It's ok, if you don't want to tell me,"  she said to me calmly, and started on her way.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მალე ავტობუსებს მივადექით.  ხალხი უკვე ბარგს აბინავებდა და თვითონაც შიგ სხდებოდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I followed behind her.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დედაბერმა ჩანთა გამომართვა და ის იყო, ავტობუსში უნდა ასულიყო, რომ შევაჩერე და ვეკითხები:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We soon got the bus stop.  People were already loading their luggage, and taking their seats inside.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხომ ვერ მეტყვით, ოჩამჩირეში რითი უნდა წავიდე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The old woman was taking her bag and was almost on the bus, when I stopped and asked:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ოჩამჩირეში?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Could you please tell me how I can get to Ochamchire?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"To Ochamchire?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დედაბერმა მიიხედ-მოიხედა და ვიღაც წვერგაუპარსავ კაცს დაუძახა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"გივი, მორთი აშო!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The old woman looked me up and down, and called out to a clean-shaven man:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კაცი მოვიდა და დედაბერს მორჩილად მიაჩერდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Givi, come here!"  ["She's speaking in Mingrelian, transliterated into Georgian: გივი, მორთი აშო!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ეს ბიჭი უნდა წაიყვანო ოჩამჩირეში."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The man came towards us, and obediently stopped by the old woman.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ქო, პატონი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"This boy needs you to take him to Ochamchire."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სახლში ხომ კარგად ხართ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes, ma'am."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვართ, ასე..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How are things at home?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მომიკითხე ეთერი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"We're all fine..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დედაბერი ახლა მე მომიბრუნდა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Say hi to Eteri."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ეს ჩემი დისშვილია, წაგიყვანს ოჩამჩირეში."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The old woman now turned to me:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გმადლობთ-მეთქი, ესღა ამოვღერღე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"This is my nephew, he'll take you to Ochamchire."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"წამოდი, ბიჭო!" მითხრა გივიმ და წინ გამიძღვა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Thank you," I said, and this was all I could manage to say.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					წავყევი.  ხალხით გაჭედილ მიკროავტობუსთან მიმიყვანა, კარი გამიღო და შიგ შემტენა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Let's go, boy," Givi said to me, and led the way.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რას შვრები, გივი, სუნთქვა არ გვინდა ჩვენ?"  დაიყვირა ვიღაცამ, მაგრამ იმას არავინ აჰყოლია.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I followed.  He led me to a microbus stuffed with people; he opened the door for me, and shoved me inside.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გივიმ მიკროავტობუსს მეორე მხრიდან შემოუარა, საჭეს მიუჯდა და დავიძარით.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What're you doing, Givi, don't we need to breath?" someone shouted, but no one else followed suit.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მე ისევ იმ დედაბერზე ვფიქრობდი -- მიკვირდა, რა რჯიდა, რატომ უთხრა აფხაზ მესაზღვრეს, ჩემი შვილიშვილიაო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Givi went around to the other side of the microbus, sat down at the steering wheel, and we started off.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					271</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I was thinking about the old woman again -- I was amazed at what she had done, why she'd said to the Abkhazian guard, "He's my grandson."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კარგი ადამიანი როგორ არ შემხვედრია, თუნდაც ის ქალი, საბანი რომ მაჩუქა, ან კიდევ, დეიდა მანანა, მაგრამ ხო ვიცი, რომ ამქვეყნად ცუდი და ბოროტი ხალხი უფრო მეტია, ვიდრე კარგი...გივის შევავლე თვალი, ესეც არ ჩანდა ურიგო კაცი, თუმცა ანას ხო თავისი სიკეთით არ მივყავდი ოჩამჩირეში, იმ დედაბერს რომ არ ეთხოვა, რა იცი, წამომიყვანდა?</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					271</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უეცრად იმ ახვარი გოჩას არეული სიფათი დამიდგა თვალწინ, გამახსენდა მისი ავად მოელვარე თვალები და მოღრეცილი პირი, საიდანაც ყვირილის დროს დორბლი სცვიოდა.  მომაგონდა მისი სიტყვებისც -- აჰა, თუ ბიჭი ხარ, მესროლეო! -- თან იარაღს მაწვდიდა.  ნაღდად მაწვდიდა, ისე კი არა, ბოლოს სკამზეც დადო და უკან გადგა, მაგრამ ვერ ავიღე... ოთახიდან გამოვვარდი და წამოვედი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Of course, I've met good people, like that woman, who gave me the blanket, or even Auntie Manana, but of course I know that in this world there are more bad and evil people, than good... I looked at Givi, he didn't look like a bad man, although he wasn't taking me to Ochamchire by his own desire; I don't know if he would've taken me if that old woman hadn't asked him.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ახლა ხშირად ვფიქრომ, სწორად მოვიქეცი თუ არა-მეთქი და ხან ერთ დასკვნამდე მივდივარ, ხანაც -- მეორემდე.  საერთოდ, ორნაირი ადამიანები არსებობენ -- კარგები და ცუდები.  რო მომეკლა, მაშინ მეც ცუდი ვიქნებოდი, მაგრამ მეორე მხრივ, არ იყო მოსაკლავი?</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Suddenly, that bastard Gocha with his messed up face appeared before my eyes, I remembered his evilly flashing eyes and his contorted mouth, which spat saliva when he screamed.  I even remember his words -- "Aha -- if you're a man, shoot" -- and at the same time he was handing me the gun.  He was handing it to me for real, not for nothing, and in the end he put it on the chair and stood back, but I couldn't pick it up.  I flew from the room, and took off.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რა თქმა უნდა, იყო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Now, I often wonder whether or not I acted rightly, and sometimes I veer towards one conclusion, and sometimes, towards another. In general, there are two types of humans -- good and bad.  If I'd killed him, then I, too, would be bad, but on the other hand, wasn't he someone who deserved to be killed?</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უნდა ამეღო ის იარაღი და მესროლა -- ჯერ ის უნდა მომეკლა და მერე დედაჩემი, სახეგათეთრებული, შეშინებული რო მომჩერებოდა და თან ცდილობდა ზეწრით შიშველი ადგილები დაეფარა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Of course he was.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მძულს ამაზე ფიქრი, ყოველთვის გავურბივარ, მაგრამ ზოგჯერ, მინდა თუ არა, მაინც ამომიტივტივდება ხოლმე მეხსიერების ზედაპირზე და მეც გულმოდგინედ ვცდილობ მის ჩაძირვას.  ბოლო ხანებში ჩემს შიგნით გამომრთველის მსგავს რაღაცას მივავენი, ის ამბავი რომ გამახსენდება, მაშინვე -- ტკაც! -- და გამოვრთავ, აღარ ვწვალობ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I should have raised the gun, and fired a shot -- I should have killed him first, and then my mother, who was staring at me, pale, frightened, and at the same time trying to cover her naked parts with a sheet...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					არც ამათ ქონიათ ჩვენზე უკეთესი გზები, უკეთესი კი არა, მგონი, უარესიცაა, ამდენ ჯაყჯაყში, ტვინის შერყევა დამემართა, თანაც, გუშინდელს აქეთ, ლუკმა არ ჩამსვლია პირში, შიმშილისგან კუჭი მეწვის, მაგრამ ისე ვართ მგზავ-</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I hate thinking about this, I'm always running away from it, but sometimes, whether I want it or not, it rises to the surface of my memory and I work hard to drown it. Recently, I've discovered something like a switch inside myself, and when I remember this event, immediately  -- "Tkats!" -- and I turn it off, I no longer suffer...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					272</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Their roads are no better than ours, not only not better, I think they're worse, there was so much bouncing that I got a concussian, and at the same time, since yesterday, I haven't had a bit to eat, and my stomach is burning from hunger, but we travellers were</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რები ერთმანეთზე მიჭუჭკულები, ძალიანაც რომ ვეცადო, ზურგჩანთას, სადაც პური, ხალვა და კილკის კონსერვები მილაგია, ვერ გავხსნი.  ისევ უნდა მოვითმინო და ოჩამჩირეში წავიხემსო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					272</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					იქამდე ბევრი აღარ დარჩა.  მე ვიცი, რომ ოჩამჩირეში შევალთ თუ არა ზღვა გამოჩნდება და ისე მიხარია, თითქოს როგორც კი მის თეთრქაფმოგდებულ ტალღებს დავინახავ, მაშინვე ყველაფერი შეიცვლება და ის უზრუნველი დრო დაბრუნდება, კელასურის პლაჟზე რომ ვატარებდით სამივენი -- დედა, მამა და მე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					crushed so closely together that even if I tried really hard, I wouldn't be able to open my backpack, where I'd put my bread, halva, and tins of sardines.  I still needed to be patient, and have a bite in Ochamchire.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დღემდე მახსოვს ზღვის სუნი, გემო და ხმა, საკმარისია თვალები დავხუჭო, რომ მაშინვე ტალღების ტლაშუნს გავიგონებ, მის მლაშე გემოსა და თევზის სუნს ვიგრძნობ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					There wasn't far to go.  I know that as soon as we get to Ochamchire, the sea will appear, and I'll be so happy, as if, as soon as I see its foamy waves, everything will change immediately, and that carefree time till return, when all three of us  -- my mom, my dad, and I -- spent time on the beach at Kelasuri.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ოჩამჩირეში არ ვიყავი ნამყოფი და ამიტომ ერთი პატარა სოფელი მეგონა, მაგრამ თურმე ვცდებოდი -- საკმაოდ მოზრდილი დაბა ყოფილა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Even now, I remember the smell of the sea, its taste, and sound, it's enough for me to close my eyes, and straight away, I hear the crashing of the waved, taste its saltiness, and smell the aroma of fish...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სანამ ზღვა გამოჩნდებოდა, ერთხანს კიდევ ვიარეთ, ბოლოს გივიმ თავისი "მარშრუტკა" ერთ პატარა მოედანზე გააჩერა და მგზავრებისაგან ფულის აკრეფა დაიწყო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I hadn't been to Ochamchire, and so I thought it was a small village, but it turned out I was mistaken -- it was a pretty big settlement.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სულ წინ ვიჯექი და ამიტომ პირველი მე ჩამოვედი.  რა თქმა უნდა, მაშინვე ზღვას მივაშურე, ღელავდა.  უზარმაზარი, მუქი ტალღებით ასკდებოდა ბეტონის ნაპირს, შხეფებს ისროდა და თან შემზარავი ხმით ღრიალებდა.  შიშით უკან დავიხიე.  არა, ასეთი ზღვა არასოდეს მენახა.  მომეჩვენა, თითქოს გზა ამებნა და სულ სხვაგან მოვხვდი, სხვა ქვეყანაში ჩამოვედი.  ვიდექი და ამდენი ხნის მონატრებული ზღვას ამედგაცრუებული, კრიჭაშეკრული ვუყურებდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We were driving for a while yet before the sea appeared, and finally Givi stopped his mini-bus ["The Russian term, transcribed into Georgian, is used: მარშრუტკა маршрутка"] in a small square and started gathering money from the travelers.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მციოდა, მშიოდა და ისიც ცხადი იყო, რომ სულ მალე დაღამდებოდა, მაგრამ აზრზე არ ვიყავი, თავი სად შემეფარებინა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I'd sat down at the very front, and so I was the first to get off.  Of course, I immediately rushed to the sea; it was choppy.  It crashed against the concrete shoreline with dark waves, splashing up, and howling with a frighenting sound.  I stepped back in fear.  No, I'd never seen the sea like this. It seemed as if I'd lost my way, and turned up at a completely different place, that I'd entered a different country. I stood there, and disillusioned, with my teeth clenched, I looked out at the sea I had longed for for so long.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უკან გამოვბრუნდი და უკვე დაცარიელებულ "მარშრუტკას" მივუახლოვდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I was cold, hungry, and it was also clear that very soon it would be night, but I had no idea where I would find a refuge for myself.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ღია კართან გივი იდგა და მიყურებდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I turned around, and approached the already emptied mini-bus.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					273</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Givi was standing by the open door, watching me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჯიბიდან ფული ამოვიღე, ორლარიანი ამოვარჩიე და მივაწოდე, მაგრამ იმან ხელი ამიქნია და მითხრა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					273</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"გაწიე, ბიჭო, იქით!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I took money out of my pocket, picked out two lari and handed them to him, but he waved his hand and said:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთხანს ჩუმად ვუყურებდი, მერე მადლობა გადავუხადე და ფული ისევ ჯიბეში ჩავიდე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Get it away from me, boy!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვისთან მიდიხარ ახლა შენ?" მკითხა მან.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I looked at him in silence for a short time, then said thanks, and put the money back in my pocket.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ისეთი სახე ჰქონდა, რომ არ მეთქვა არ იქნებოდა და ამიტომ გამოვუტყდი:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Who are you going to visit now?" he asked me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ტყვარჩელში, მამასთან."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He had an expression on his face that demanded the truth, so I confessed:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ტყვარჩელში?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"To Tq'varcheli, to my father's."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"To Tq'varcheli?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ტყვარჩელში როგორ წახვალ?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yeah."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მხრები ავიჩეჩე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How are you going to get to Tq'varcheli?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"საიდან მოდიხარ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I shrugged my shoulders.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"თბილისიდან..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Where are you from?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"აუჰ, რას ამბობ!"  შეიცხადა და მერე ჩაფიქრდა, "დაჯექი!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Tbilisi."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თვითონ მანქნას შემოუარა, საჭეს მიუჯდა და დაქოქა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Ooh, what are you saying!" He reacted with surprise, then fell into thought -- "sit down!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მეც ავედი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He went around the vehicle, sat down at the wheel, and turned on the engine.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გივიმ მანქანა დაძრა და მერე მომიბრუნდა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I got in, too.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ტყვარჩელში როგორ წახვალ, არ ვიცი, მარა ახლა სადაცაა დაღამდება და ძილი გინდა შენ... ხომ გინდა?  მიგიყვან ართ ოჯახში... ახლობლებია, გაჭმევენ, გასმევენ, და გაძინებენ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Givi got the car moving, then turned to me:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კარგა ხანს ვიარეთ და ერთ სახლს მივადექით.  გივიმ დაასიგნალა.  სამზადის კარი გაიღო და იქიდან ქალმა გამოიხედა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I don't know how you'll get to Tq'varcheli, but it's almost night now, and you need to sleep, don't you?  I'll take you to a family...  they're close relatives, they'll feed you, give you something to drink, and let you sleep there..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ზიტა, დაური დომა?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We drove for quite a while and stopped at a house.  Givi blew his horn.  The kitchen door opened, and a woman looked out.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნიეტუ ევო, გივი, ნიეტუ!?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Zita, is Dauri home?" ["The driver is speaking in Russian, transliterated into Georgian:  ზიტა, დაური დომა? Зита, Даури дома?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"აუ, აფხაზები!"  გავივლე გულში და შიშისაგან თმამ შმაშური დამიწყო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"No, Givi, he's not here!" ["She, too speaks in Russian, transliterated:  ნიეტუ ეგო, გივი, ნიეტუ! Нету, его, Гиви, нету!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ა გდე ონ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Oh no, Abkhazians!"  It crossed my mind, and my hair started to tingle from fear.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სკორო პრიდიოტ, ზახოდი!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And where is he?" ["She is still speaking in Russian: ა გდე ონ? А где он?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					274</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"He'll be here soon, come in!" ["More Russian:  სკორო პრიდიოტ, ზახოდი! Скоро придет, заходи!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გივი გადავიდა და სახლისაკენ გაემართა, მაგრამ მაშინვე ისევ უკან მობრუნდა, მანქანაში შემოიხედა და მითხრა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					274</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"შენ არ წახვიდე, ბიჭო, არსად!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Givi got down and headed towards the house, but came back right away, looked into the car, and said to me:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საშიში რომ ყოფილიყო, ეს კაცი აქ არ მომიყვანდა-მეთქი, გავიფიქრე, მაგრამ მაინც ვერ დავმშვიდდი, ვიჯექი და ათას სისულელეზე ვფიქრობდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Don't go anywhere, boy!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლოს გივი მოვიდა, მანქანის კარი გამიღო და წამოდიო, მითხრა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					If it were dangerous, this man wouldn't have brought me here, I thought to myself, but still I wasn't able to calm down; I sat, and thought of a thousand silly things.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ქალი ეზოს ჭიშკართან დაგვხვდა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Finally Givi came towards me, opened the car door, and said, "Come on."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"იდი, სინოკ, იდი... გივი, ზახოდი ტი ტოჟე, დაურ სკორო პრიდიოტ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The woman met us at the gate of the yard.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნიკოგდა, ზიტა, პოიდუ ია..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Go on, kiddo, go... Givi, you come in, too, Dauri will be here soon." ["More Russian, transliterated into Georgian: იდი, სინოკ, იდი..გივი, ზახოდი ტი ტოჟე, დაურ სკორო პრიდიოტ. Иди, сынок, иди...Гиви, заходи ты тоже, Даур скоро придет."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნუ, ლადნო," უთხრა ქალმა და მერე მე მომიბრუნდა, "ა ნუ, პაშლი!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I don't have time, Zita, I'll be on my way..." ["ნეკოგდა, ზიტა, პოიდუ ია...  Некогда, Зита, поиду я."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დიდი, კოინდარიანი ეზო გადავიარეთ და სამზადში შევედით.  იქ თუნუქის ღუმელი გუზგუზებდა და თბილოდა.  ღუმელზე ქვაბი დგა, საიდანაც ორთქლის ოხშივარი ამოდიოდა.  დალიშხულ ოთახში მოხარშული ხორცის სურნელი ტრიალებდა.  კუჭი უარესად ამეწვა.  რა არი მაინც ეს შიმშილი, ყველანაირ შიშზე მაგარია.  ზიტას მლიქვნელური ღიმილით მივაჩერდე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Well, ok," the woman said to him, and then she turned to me,"Well, let's go!" ["ნუ ლადნო...ა ნუ, პაშლი!  Ну ладно... А ну, пошли!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ტი კტო?" მკითხა მან.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We crossed the large, grass covered yard and went into the kitchen.  A iron stove was humming there, and it was warm.  A pot stood on the stove, with steam rising out of it.  The aroma of boiled meat filled the "XXX dalishkhul XXX " room.  My stomach started to burn even more.  Hunger's an amazing thing, when it's stronger than any kind of fear.  I stared at Zita with a flattering kind of smile.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხელებით რაღაც უაზრო მოძრაობა გავაკეთე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"You are you?" [More transliterated Russian: ტი კტო? ты кто?"]  She asked me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ჩტო, ნემოი?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I made some kind of senseless motion with my hands.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სასწრაფოდ თავი დავუქნიე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What, are you dumb?" ["More transliterated Russian: ჩტო, ტი ნემოი? Что, ты немой?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ააა, გრუზინ, და?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I immediately nodded my head.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					შემატყო, დაფეთებულმა კარისკენ რომ გავიხედე, ხმამაღლა გადაიკისკისა და უცებ ქართულად მომმართა:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Aha, you're Georgian, aren't you?"["More transliterated Russian: ააა, გრუზინ, და? ааа, грузин, да?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნუ გეშინია, შენ გგონია, ქართველი რომ ხარ, შეგჭამ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					She noticed that terrified, I looked towards the door; she laughed out loud and suddenly addressed me in Georgian:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					პირდაღებული მივაჩერდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Don't be afraid, do you think I'm going to eat you because you're Georgian?</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ის იცინოდა, გემრიელად კისკისებდა, მერე ღუბელთან მივიდა და ქვაბს სახურავი ახადა.  იქიდან სქელ ბოლქვებად ამოიშალა ცხელი ორთქლი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I stared at her with my mouth wide open.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					275</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					She laughed, deliciously emiting peals of laughter, then went to the stove and took the lid off the pot.  Hot steam rose up in dense puffs.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რა გქვია?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					275</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"გია," ვიცრუე უნებურად.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What's your name?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სადაური ხარ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Gia," I lied involuntarily.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"თბილისელი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Where're you from?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო გშია?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I'm from Tbilisi... "</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რაღა კითხვა მინდოდა, დამახრჩო ნერწყვმა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I bet you're hungry?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ეხლავე ყველაფერი იქნება..." კარადიდან თეფშები და ჩანგლები გამოალაგა, "გაიხადე და დაჯექი, ფეხზე რატომ დგახარ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Why did I need to be asked, saliva had choked me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზურგჩანთა მოვიხსენი და კარსუკან დავდე, მერე ბუშლატიც გავიხადე, ზურგჩანთას ზემოდან დავადე, ღუმელთან კსამი მივიტანე და დავჯექი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Everything will be ready in just a minute... " She got out plates and forks from the cupboard. "Take off your coat and sit down, why are you standing?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სითბომ სასიამოვნოდ დამიარა ძარღვებში, მომთენთა, თვალები დავხუჭე. ჯდომელა ძილის ოსტატი ვიყავი, სულ ეგრე არ გვეძინა მე და წუპაკას, ავანთებდით პაკრიშკას და მიდიი!  -- მთელი ღამე ქვის პარაპეტზე ვისხედით და გვეძინა... პაკრიშკა ტკაცუნობს, ნაპერწკლებს ისვრის და ისე ცხელა, უკან თუ არ გაიწიე დაიწვები... გესმის ჯამ-ჭურჭლის ჩხარუნი და გესიზმრება, ვითომ შინა ხარ, დედა სუფრას აწყობს... მაგრამ ეს დედა როდია, ეს დევის ქალია, რომელმაც კარადის უკან დაგმალა, რომ ნადირობიდან შინ დაბრუნებულმა დევმა არ შეგჭამოს, სუფრასაც მისთვის აწყობს და თან რაღაცას ღიღინებს.  კარადის უკან ცხელა, თუმცა ეს კარადა კი არა, გახურებული ღუმელი ყოფილა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I took off my backpack and lay it behind the door, then I took off my pea-coat, and lay it on top of my backpack, drew a chair towards the stove, and sat down.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უცებ, კარი იღება და სამზადში დევი შემოდის...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The warmth traveled pleasantly through my veins, made me tired, I closed my eyes.  I was a master of sleeping while sitting -- Tsupaka and I always slept like that -- we'd light a tire, and away!  We sat the entire night on the stone sidewalk, and slept... the tire is crackling, throwing off sparks so hot that if you don't move back you'll be burned.  You hear the clattering of the dishes, and you dream, that you're back home, your mother is setting the table... but what kind of a mother is this, this is an ogre's wife, who hid you behind the cupboard so the ogre won't eat you when he returns home from hunting, she's setting the table for him and quietly singing something.  It's hot behind the cupboard, though this isn't just a cupboard, it's a red-hot stove...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ადამიანის სუნი მცემს..." ამბობს ის.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Suddenly, the door opens, and the ogre walks into the kitchen...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ისეთი მაღალია, თვალს ვერ შეუწვდენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I smell a human..." he says.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ეტო ეშჩო კტო?!"  რატომღაც რუსულად ეკითხება ქალს და ქალიც რუსულადვე პასუხობს, "ეტო? ეტო გია, იზ ტბილისი..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He's so tall, you can't see to the top of him.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"გრუზინ?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And who's this?!" ["Transliterated Russian: ეტო ეშჩო კტო?! Это еще кто?"] For some reason he asks the woman in Russian, and she answers in Russian. "This?  This is Gia, from Tbilisi..." ["Transliterated Russian:ეტო?  ეტო გია, იზ ტბილისი...Это? Это Гиа, из Тбилиси..."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"და, გივი პრივიოლ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"A Georgian?" ["გრუზინ?  Грузин?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"კაკოი გივი?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes, Givi brought him." ["და, გივი პრივიოლ. Да, Гиви привел."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					276</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Givi who?" ["კაკოი გივი? Какой Гиви?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სხულუხია.  სკაზალ, ჩტო ონ ვ ტკვარჩელი ედიტ, კ ოტცუ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					276</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ლადნო, ა დალშე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Skhulukhia.  He said he's going to Tq'varcheli, to his father." ["სხულუხია.  სკაზალ, ჩტო ონ ვ ტკვარჩელი ედიტ, კ ოტცუ. Схулухиа.  Сказал, что он в Ткварчели идет, к отцу."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"დალშე ჩტო, სპატ ბუდეტ უნას, ა უტრომ პოედეტ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"OK, and after that?" ["ლადნო, ა დალშე? Ладно, а далше?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ა კუდა ტი იგო პოლოჟიშ, დურა, სმოტრი, კაკოი ონ გრიაზნი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What do you mean after that?  He'll sleep with us, and in the morning, he'll go." ["დალშე ჩტო, სპატ ბუდეტ უნას, ა უტრომ პოედეტ. Далше что, спатъ будет унас [sic] а утром поедет."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სს, ტიშე უსლიშიტ..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And where are you going to let him sleep, you fool, look, how dirty he is." ["ა კუდა ტი ეგო პოლოჟეშ, დურა, სმოტრი, კაკოი ონ გრიაზნი. А куда ты его положишь, дура, смотри, какой он грязный."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ყველაფერი კარგად გავიგონე, მაგრამ აფხაზები თუ არიან, რუსულად რატომ ლაპარაკობენ?  ცოლმა კარკი ქართული იცის, მაგრამ ქმარმა?  იქნებ ეს ქალი ქართველია, კაცი კი აფხაზი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Shsh, be quiet, he'll hear." ["სს, ტიშე, უსლიშიტ...  СС, тише, услышит..."]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					თვალები რომ გავახილე და იმ ქალის ქმარი დავინახე, გამიკვირდა:  რა დევი, ჩვეულებრივი ადამიანი იყო -- საშუალო ტანისა, სუფთად გაპარსული, ქართველისგან ვერ გაარჩევდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I understood everything very well, but if they are Abkhazians, why are they speaking in Russian?  The wife speaks good Georgian, but the husband?  Maybe the wife is Georgian, and the husband Abkhazian.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ფეხზე წამოვდექი და თავი დავუკარი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When I opened my eyes and looked at the woman's husband, I was amazed:  What kind of ogre was he -- he was an ordinary human being -- medium height, clean-shaven;  I couldn't tell him apart from a Georgian.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"გამარჯობა, შენი!" მითხრა მან./</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I stood up, and bowed.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უყურე, ამასაც კარგი ქართული სცოდნია?!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Hello, you," he said to me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზიტას სუფრა გაეშალა, ოთახში გემრიელი, მადისაღმძვრელი სურნელი ტრიალებდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Look at that, he, too, speaks good Georgian?!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"წამოდი, ხელები გავიბანოთ!  მითხრა კაცმა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Zita set the table, a delicious, appetizing aroma filled the room.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ზიტამ კარადიდან ახალი პირსახოცი გამოიღო და ქმარს მისცა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Come on, let's go wash our hands," the man said to me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გარეთ გავედით და ეზოში, წყალსაქაჩზე ხელები დავიბანეთ.  მე რო ვიბანდი, წყალსაქაჩის ბერკეტს ის ამოძრავებდა, ის რო იბანდა -- მე ვამოძრავებდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Zita took a new towel from the cupboard, and handed it to her husband.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ეს ჭასთან არის მიერთებული," მიხსნიდა დაური, "მატორიცა აქ, მაგრამ ეხლა დენი არ არი და ამიტომ ხელით ვაკაჩავებ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We went outside and into the yard, and washed our hands at a pump. When I was washing, he turned the handle of the pump, and when he was washing, I did it.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					როგორც იყო გავბედე და ვკითხე:</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"This is connected to a well," he explained to me, "it has a motor, but there isn't any electricity now, so we have to pump it by hand."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"თქვენ აფხაზები ხართ თუ ქართველები?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I finally got brave, and asked:</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დაკვირვებით შემომხედა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Are you Abkhazians, or Georgians?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"აფხაზები.  რა იყო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					He looked at me in amazement.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					277</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Abkhazians.  Why do you ask?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"არა, არაფერი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					277</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რუსულად რო ვლაპარაკობთ"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Oh, it's nothing."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Is it because we're speaking Russian?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ორივეს რუსული სკოლა გვაქ დამთავრებული და იმიტო.  კლასელები ვიყავით."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yeah."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"და ქართული საიდან იცით?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Both of us graduated from a Russian high school, that's why.  We were classmates."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"როგორ საიდან," გაეცინა დაურს, "ქართველი დედები გვყავდა მეც და მაგასაც."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And where do you know Georgian from?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხელები სუფთა, ხაოიანი პირსახოცით შევიმშრალეთ, შინ შევედით და მაგიდას მივუსხედით.
													</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"What do you mean, from where?" Dauri let out a laugh,"Both she and I have Georgian mothers."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დაურმა ჭიქებში ვარდისფერი ღვინო ჩამოასხა, ზიტამ კი თეფშზე ქათმის ჩახოხბილი გადმომიღო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We dried our hands with the clean, rough towel, went inside, and sat down at the table.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ამისთანა გემრიელი არაფერი მეჭამა, მადიანად ვიღმურძლებოდი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Dauri poured rose-colored wine into glasses, while Zita dished out chicken "chakhokhbili" onto the plates.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					არ ვიცი რისი ბრალი იყო, ალბათ, იმ სამი ჭიქა ღვინისა, დაურთან ერთად რომ დავლიე, მთელი ღამე გაუნძრევლად მეძინა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I had never eaten anything as delicious as this, I devoured it with gusto.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დილით ზიტას ხმამ გამაღვიძა -- ქათმებს ეძახდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I don't know why, maybe the three classes of wine I drank with Dauri, but I slept the entire night without stirring.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სკამზე გაწმენდილი, შეძლებისდაგვარად გასუფთავებული ჩემი ტანისამოსი ელაგა, სკამქვეშ -- ზურგჩანთთა და ფეხსაცმელები.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the morning, Zita's voice woke me up -- she was calling to the chickens.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ავდექი, ჩავიცვი, ზურგჩანთა მოვიკიდე და ეზოში ჩავედი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					She had placed my clothes, cleaned, or washed as much possible, on a chair, beneath the chair were my backpack and my shoes.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"საით?" მკითხა დაურმა, რომელიც სამზადის საჩიხში ცულს ქლიბით ლესავდა, "ჯერ ჩაი დავლიოთ, მერე მე თვითონ გაგაცილებ."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I got up, got dressed, put on my backpack, and went out into the yard.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"არა, არა. დიდი მადლობა..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Where are you off to?" asked Dauri, who was sitting in an alcove of the kitchen, sharpening his axe with a metal file."Let's drink tea first, then I'll see you off."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ზიტა,"  დაიყვირა დაურმა, "სმოტრი, ტვოი გოსტ უხოდით!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Zita," Dauri called out,"Look, your guest is leaving!" [Zita and Dauri speak Russian with each other: "სმოტრი, ტვოი გოსტ უხოდიტ! Смотри, твой гость уходит!"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მოვიდა ზიტა, ზურგჩანთა ძალით მომხსნა და შემიყვანა სამზადში, სადაც უკვე მაგიდა იყო გაწყობილი.  შემოვიდა დაურიც.  დავსხედით, დავლიეთ ჩაი, მივაყოლეთ ცხელ-ცხელი ხაჭაპურები და დაურმა მითხრა, რომ მართალია ტყვარ-</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Zita came out, took my backpack off by force, and took me into the kitchen, where the table was already set.  Dauri came in, too.  We sat down, drank tea, ate piping hot "khachapuri," ["A Georgian dish of cheese in or on bread."] and Dauri told me, that yes, it's true, the electric tram</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					278</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					278</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ჩელში ელექტრიჩკა აღარ დადიოდა, მაგრამ შეეცდებოდა იქით მიმავალი რაიმე მანქანისთვის გავეყოლებინე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					no longer runs to Tq'varcheli, but he'd try to send me by some kind of car that was going there.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საუზმეს რომ მოვრჩით, ავდექი და ზურგჩანთა ავიკიდე.  დაურმა თავისი ქურთუკი ჩაიცვა. შევნიშნე, როგორი თვალებით მიყურებდა ზიტა და ამიტომ, როცა ვემშვედობებოდი, გავუღიმე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When we finished breakfast, I got up and put on my backpack.  Dauri put on his warm jacket.  I noticed how Zita was looking at me, and when I was saying goodbye, I smiled at her.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"შენ იცი, გია," მითხრა მან, "აქეთ რომ იქნები, აუცილებლად შემოგვიარე..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"You know, Gia," she said to me,"when you come this way again, absolutely come to visit us."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უეცრად მომინდა, ზიტასთვის ჩემი ნამდვილი სახელი მეთქვა, მაგრამ მივხვდი, რომ არ გამოდიოდა, რაღაც წავიბურტყუნე და სამზადიდან საჩქაროდ გავედი.  უკან დაური მომდევდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Suddenly I felt like telling Zita my real name, but I guessed that it wouldn't be a good idea, so I mumbled something and quickly went out of the kitchen.  Dauri followed behind me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გავიარეთ მწვანე მოლით შემოსილი ვრცელი ეზო და გზაზე გავედით ტრიფოლიატის ღობეებს იქით მოჩანდა კოინდარიანი ეზოები, სადაც ყიოდნენ მამლები, დაკივკივებდნენე ინდაურები.  ერთგან, ხურმის ხეზე, წითელი ხბო ება თოკით, მოლზე ჭრელი ბურთი ეგდო, ჭიდან კი შავთავსაფრიანი აფხაზის ქალი წყალს იღებდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We crossed the large yard, covered with fresh, rich green grass, and we when went out onto the road, beyond the fences of Japanese orange trees you could see rye-grass yards, where roosters were crowing, and turkeys gobbling.  In one place, a red calf was tied by a rope to a persimmon tree,  at the far edge stood a multi-colored bull, and an Abkhazian woman, her head covered with a black scarf, was drawing water from a well.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					წინ დაური მიდიოდა, მე უკან მივდევდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Dauri was walking in front, I followed behind.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					შემოგვხვდა ვიღაც ხნიერი კაცი, რომელიც სიგარეტს გრძელტარიანი მუნდშტუკით ეწეოდა.  დაურმა და იმ კაცმა ერთმანეთს ხელი ჩამოართვეს, მერე აფხაზურად რაღაც ილაპარაკეს.  ლაპარაკობდნენე და თან წამდაუწუმ ჩემსკენ იყურებოდნენ.  გამომშვიდობებისას იმ კაცმა გამიღიმა და თამბაქოსაგან ჩაყვითლებული კბილები გამოაჩინა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We met an old man who was smoking a cigarette in a long-filtered holder.  Dauri and that man shook hands, then said something in Abkhazian.  The were talking and constantly looking towards me.  When he was saying goodbye, the man smiled at me, and you could see his teeth, yellow from the tabacco. </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოგირთან დაური შედგა და ტრასას გახედა.  მაინცადამაინც დიდი მოძრაობა არ ყოფილა, იშვიათად თუ გაივლიდა მანქანა.  მერე ორივენი ბოგირის ბეტონის მოაჯერზე ვისხედით და ტყვარჩელისკენ მიმავალ ტრანსპორტს ველოდებოდით.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Dauri stood by a planked bridge and looked at the hightway.  There wasn't particularly a lot of traffic, rarely would a car pass by. Then we both sat on the concrete railing of the bridge, and waited for a vehicle going to Tq'varcheli.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საკვირველია, მაგრამ დაური არაფერს მეკითხებოდა.  ერთხანს მომეჩვენა, რომ დავავიწყდი კიდეც, ჩუმად იჯდა და თამბაქოს ახვევდა.  ვუყურებდი, როგორ მარჯვედ ამოძრავებდა სიგარეტის კვამლისგან გაყვითლებულ თითებს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It was amazing, but Dauri didn't ask me anything. Once, it seemed to me that he even forgot about me, he sat silently and rolled his tabacco.  I watched how he skillfully moved his fingers, yellowed from cigarette smoke.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					279</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					279</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					შეხვევას რომ მორჩა, ქაღალდს ენა გაუსვა, მერე ჯიბიდან სანთებელი ამოიღო და სიგარეტს მოუკიდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When he finished rolling, he licked the paper with his tongue, then took a lighter out of his pocket and lit his cigarette.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვიფიქრე, მოდი მე მაინც ვკითხავ რამეს, ასე როდემდე უნდა ვისხდეთ-მეთქი, მაგრამ ვერაფერი მოვიფექრე, აზრზე არ ვიყავი, რა უნდა მეკითხა, ისედაც ყველაფერი ნათელი იყო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I thought I should at least ask something, for example, how long would we sit, but I couldn't think of anything, I had no idea what I should ask, and also, everything was clear.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლოს ერთმა საბარგო მანქანამ გამოიარა, დაურმა ხელი დაუქნია და გააჩერა.  სულ რამდენიმე სიტყვა უთხრეს ერთმანეთს, მერე ძარაზე ასვლაში მიშველა და მანქანა რო დაიძრა, ხელი დამიქნია.  ისე მემშვიდობებოდა, თითქოს დროებით მივდიოდი სადღაც და მალე უკან უნდა დავბრუნებულიყავი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Finally, a transport truck arrived; Dauri waved his hand and stopped it.  They spoke a few words to each other, then he helped me up into the cabin, and when the vehicle started to move he waved to me.  He said goodbye to me as if I were going somewhere for just a short time, and was supposed to come back soon.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ძველი, ვინ იცის, რამდენჯერ შეკეთებულ-შერემონტებული მანქანა აღმართს ხროტინით მიუყვებოდა...ხეობის ფერდობებზე ფოთოლგაცლილი, აქა-იქ სიმწვანეშერჩენილი ტყე მოჩანდა...აქეთ და აქეთ უფრო ციოდა...ვცდილობდი წარმომედგინა მამისა და ბებიის სახეები, მაგრამ ვერ ვახერხებდი.  ბებია საერთოდ არ მახსოვდა, რადგან იგი გუდაუთაში ცხოვრობდა და იშვიათად ვნახულობდი, მამის სახე კი ბუნდოვნად მედგა თვალწინ და მასაც დედაჩემის სახე ფარავდა -- იგი თანდათანობით ახლოვდებოდა, იზრდებოდა, ფართოვდებოდა და ზედ ეფარებოდა მამაჩემის ფერმკრთალ სახესა და ბებიის მოხრილ ზურგს.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					The old car -- who knows how many times it had been rebuilt and repaired -- made its way up the incline, puffing... On the sides of the valley you could see the forest, with the leaves fallen, but still green in places... the further we went, the colder it got...I tried to imagine my father and grandmother's faces, but I couldn't quite do it. I absolutely didn't remember my grandmother, becasue she lived in Gudauta, and I rarely saw her; my father's face stood before my eyes vaguely, and my mother's face concealed it -- hers would gradually draw closer, grow, widen, and hide my father's pale face, and my grandmother's bent back.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მამა უკანასკნელად ცხრა წლის წინათ ვნახე ავადმყოფი, ტკივილებისაგან გატანჯული, სახეგაცრეცილი.  ვიგონებდი მის გაფართოებულ თვალებს, სიბრაზისაგან მოღრეცილ პირს, მაგრამ ეს თვალები, ეს პირი, ეს სახის ფერი მაინც ცალ-ცალკე იყვნენ და ვერაფრით ვერ გამეერთიანებინა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I saw my father for the last time nine years ago; he was sick, tormented and ashen from pain.  I imagined his wide eyes, his mouth, twisted from anger, but his eyes, his mouth, the color of his face were all separated, and there was no way I could bring them together.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საკვირველი იყო, მაგრამ მამისა ყველაზე მეტად სუნი მახსოვდა.  ეს იყო თამბაქოს, მჟავე ღვინისა და კიდევ რაღაცის სუნი.  ეს სუნი უდიოდა მის ტანისამოსს, მის წიგნებს, ბინას, სადაც ჩვენ ვცხოვრობდით.  ეს სუნი მიყვარდა.  შემეძ-</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					It's amazing, but most of all, I remembered my father's smell.  It was a smell of tobacco, sour wine, and something else.  This smell permeated his clothes, his books, the apartment where we lived. I loved this smell.  From this smell I was able</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					280</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					280</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ლო ამ სუნით მივმხვდარიყავი, რომ მამა ღამის ცვლიდან შინ დაბრუნდა და ახლა საცაა ლოგინში მწოლს თავზე დამადგენოდა და ცივ, ჩხვლეტია ლოყას ლოყაზე მომადებდა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					to figure out when my father had returned from his night shift and would soon stand over me, as I lay in bed, and touch his cold, bristly cheek to mine...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ტყვარჩელში რომ შევედით, ქალაქი ვეღარ ვიცანი.  მარტო იმიტომ კი არა, რომ შეცვლილიყო (ყველაფერს რომ თავი დავანებოთ, ისევ ისე იდგა ტყით შემოსილი გორები, სადაც, აქა-იქ ისევ მოჩანდა წითელკრამეტიანი სახლები, ხოლო ქვემოთ, სადგურთან ახლოს -- გრესის საკვამლე მილები), ალბათ იმიტომაც, რომ წინათ ყოველთვის ელექტრიჩკით ვმგზავრობდი, ახლო კი სამანქანე გზით მოვედი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When we got to Tq'varcheli, I didn't recognized the city.  Not only becasue it had changed, (in spite of this, the hills stood, as before, covered  by the forest, where you could see scattered red-tile-roofed houses, and below, near the station -- the smokestacks of the Gresi factory), but perhaps also because earlier I used to travel by the electric commuter train, but now I was on a highway. </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მძღოლს ბაზართან (სადღა იყო ბაზარი!) დავემშვიდობე და გულაჩქროლებული ზემოთ შევუყევი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I said good-bye to the driver at the market (and where was this market?!) and with my heart pounding, I headed up.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					აი, ისიც -- ჩვენი კორპუსი!  წინ ღელე ჩამოუდის, ბოგირს გადაივლი და ეზოში შეაბიჯებ, იქ კი პირველივე სადარბაზო ჩვენია... მაგრამ ეზოში არავინა ჩანს, ხოლო კორპუსი...მთელს კორპუსს ერთი ფანჯარაც აღარ შერჩენია...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Here, here it is -- our apartment building! A small creek ran in front of it; I crossed a planked bridge and stepped into the yard, there, the very first entrance is ours... But no one was in the yard, just the building...  not a single window remained in the entire building.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გახევებული ვდგავარ, აღარ ვიცი, როგორ მოვიქცე...მერე სადარბაზოში შევდივარ...ჩვენს ბინას კარი აღარა აქვს...შიგნით სიცარიელეა, იატაკზე ნაგავი ყრია -- რაღაც გამოუსადეგარი ნივთები და მათ შორის ჩემი ნაჭრის დათუნია "გერასიმე," რომლისთვისაც ვიღაცას მკლავი მოუგლეჯია...ხელში ვიღებ და ვათვალიერებ.  "ნაჭრილობევიდან" გერასიმეს ნაცრისფერი ბამბა გამოსჩრია, რომელსაც, რატომღაც, თითით შიგ ვუტენი და აქეთ-იქით ვიყორები -- მკლავიც იქვე გდია... ვიღებ და გერასიმეს მხარზე ვადებ.  ნემსი და ძაფი რომ იყოს, მივაკერებდი, მაგრამ სად არი ნემსი და ძაფი!</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I stood, numb, I no longer knew what to do... then I went into the entrance... our apartment no longer had a door... inside, it was empty, garbage was strewn on the floor -- useless stuff, and in the midst of it all, my cloth teddybear, "Gerasime," from whom someone had torn his arm.  I picked him up in my hand, and looked at him.  Gray cotton was sticking out of Gerasime's "wounds," and for some reason, I stuck it back in with my finger, and looked all around -- his arm was over there... I picked it up and put it up to Gerasime's shoulder.  If only I had needle and thread, I would sew it on, but where can I find need and thread!</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ბოლოს გერასიმე თავისი მკლავიანად ზურგჩანთაში ჩავდე და წამოვედი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Finally, I put Gerasime in my backpack, and left.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ეზოს ბოლოში ისევ დგას ბეტონის მაგიდა თავისი გრძელი სკამით.  აქ წინათ ჩვენი მეზობლები დომინოს თამაშობდნენ ხოლმე, ისმოდა დომინოს ქვების ჭახაჭუხი, საანგარიშო კოჭების ჩხაკუნი და მხიარული შეძახილები, მაგრამ იქ</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					At the end of the yard stood the same concrete table with its long benches.  Before, our neighbors used to play dominoes here, you could hear the clattering of the domino pieces, the clicking of the abacus beads, but</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					281</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					281</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ახლა აღარავინ ზის და როგორც ჩანს, დიდი ხანია, არც არავინ მჯდარა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					now no one's sitting there, and it seems like no one has sat there for a long time.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					რა ვქნა, ნუთუ მართლა არავინ დარჩა, რომ მამაჩემის ამბავი ვკითხო, ნეტა სად წავიდა იმდენი ხალხი...ბეტონის სკამზე ვჯდები და ეზოს ჩუმად ვათვალიერებ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					What could I do, if there's really no one left to ask about my father; I wonder where so many people have gone...I sit down on the cement bench, and look at the yard in silence.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უეცრად, ჩვენი სადარბაზოდან ვიღაც შაუსანი დედაბერი გამობრაცუნდა, ხელში ვერდო ეჭირა და პირდაპირ ჩემსკენ მოდიოდა, მაგრამ რომ დამინახა შეკრთა და ვედრო ხელიდან გაუვარდა.  წამოვდექი.  დედაბერმა თვალებზე ხელი მოიჩრდილა, ამხედ-დამხედა და უეცრად, რაღაც სასწაულის ძალით. ვიცინი -- ჩვენ ზემოთ, მესამე სართულის ერთოთახიან ბინაში ცხოვრობდა.  სახელი ვეღაღ გავიხსენე, მაგრამ მაინც მივედი, ვედრო ავიღე, მევაწოდე და ღიმილით მივაჩერდი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Suddenly, an old woman dressed in black was stumbling out of our entrance; she held a bucket in her hand and was coming straight towards me, but when she saw me she startled, and dropped the bucket.  The old woman shaded her eyes with her hand, looked me up and down, and by the force of some miracle, I recognized her -- she used to live above us, in a third floor, one room apartment.  I couldn't remember her name yet, but I still walked towards her, picked up the bucket, gave it to her, and I stared at her with a smile.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რომელი ხარ?" მკითხა და კუშტი სახით შემომხედა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Who are you?" She asked, and looked at me with a stern face.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ჩვენ აქ ვცხოვრობდით პირველ სართულზე..." -- და იმავე სასწაულის ძალით ახლა სახელიც გამახსენდა, "თქვენ ხომ მარო ხართ, მარო ბებია..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"We used to live here, on the first floor..." and by the force of that same miracle, I now remembered her name, "You're Maro, arent' you, Granny Maro..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნენა, ქეთოსი ხარ, ბიჭო, შეენ?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I am, and you, you're Keto's son, boy?!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"დიახ..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"აქ როგორ მოხვდი მერე?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"And how in the world did you get here?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"თბილისიდან ჩამოვედი..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I came from Tbilisi..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"თბილისიდან?! დედა, რას ხედავს ჩემი თვალები!  რაფერაა, შვილო, ქეთო, ცოცხალია?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"From Tbilisi?!  Oh my god! What do I see?  How is Keto, my child, is she alive?" "["Maro speaks in a local dialect of Western Georgia:  რაფერაა for როგორაა?"]</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ცოცხალია, კი...თბილისში ვცხოვრობთ.  მე მამაჩემის სანახავად ჩამოვედი, მაგრამ..."  ჩვენი ბინისკენ გავიხედე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"She's alive, and... we live in Tbilisi.  I've come to see my father, but... " I looked towards our apartment.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ნუ გეშინია, შვილო, ცოცხალია ისიც, კარგადაა, მარა...ცოლი შეირთო და წავიდა აქედან... შენ არ ინერვიულო, ბებია, რა ექნა, მომვლელი ხო ჭირდებოდა ავადმყოფ კაცს..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Don't be afraid, my child, he's alive, too, and is well, but... he married and left... don't worry, honey, what could he do, after all a sick man needs a caregiver..." </p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სანამ არ ჩავახველე, კრინტი ვერ დავძარი.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I couldn't make a sound until I cleared my throat.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					282</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					282</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"სად წავიდა?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Where did he go?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"არ ვიცი, ბებია, ჯერ თქვეს, სოხუმში ცხოვრობსო, მერე არმავირშიო და რა გითხრა.."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I don't know, honey, they said he was living in Sokhumi, then in Armaviri, but what can I tell you..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ერთხანს ჩუმად ვიდექით, ერთმანეთს არ ვუყურებდით, მერე მალულად შევათვალიერე -- დაბერებულიყო, მე სულ სხვანაირი მახსოვდა და გამიკვირდა, როგორ ვიცანი-მეთქი...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We stood in silence for a while, we didn't look at each other, then I glanced at her -- she'd grown old, I remembered her completely differently, and I was amazed that I'd recognized her, I thought to myself...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"კარგი, მარო ბებია, წავალ ახლა მე..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"OK, Granny Maro, I'll be on my way now..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ღმერთო კი მომკალი,"  შეიცხადა მან, "სა წახვალ, ბიჭო?!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"May God kill me!" she cried out, "Where will you go, boy?!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რა ვიცი, წავალ..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"How should I know, I'll just go..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					უეცრად მკლავში ხელი წამავლო.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					She suddenly grabbed me by the arm.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"არ გაგიშობ, არა...სად უნდა წახვიდე ახლა!"  პირზე ტკბილი ღიმილი მოეფინა, "ჩაის დაგალევიებ, კვერცხს მოგიხარშავ...თლათ დაღუპვილი კი არ ვართ!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"I won't let you go, no... where would you go now?"  A sweet smile appeared on her face, "I'll give you some tea, I'll boil you some eggs.. we're not completely ruined!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ღელედან ვედროთი წყალი ამოვიღეთ და მაღლა ავედით.  დედაბერი დაფაცურდა, ნავთქურაზე ქვაბით წყალი დაადგა და შიგ მოსახარშად ორი კვერცხი ჩადო.  მე ჩემი ზურგჩანთა გავხსენი და იქიდან პური, "კილკის" კონსერვი და ხალვა ამვიღე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					We got water from the creek with the bucket and went upstairs.The old woman started to bustle about, put water in a pot on the gas burner, put in two eggs to boil.  I remembered my backpack, and took out the bread, the tin of "sardines" and the halva.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ხალვას დანახვაზე დედაბერს თვალები გაუბრწყინდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When she saw the halva, the old woman's eyes lit up.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მაი სად იშოვე?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Where did you find this?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხალვა?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"The halva?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ჰო."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					გამეცინა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I laughed.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ხალვას მიაქვს თბილისი."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Tbilisi is full of halva!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"დედა, რა კაია!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Oh my God, it's amazing!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"ვინ მოიყვანა ცოლად..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Who did he marry?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"მამაშენმა? ლიდა."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Your father? Lida."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"რომელი, აქ რო ცხოვრობდა?"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"You mean the one who lived here?"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					"კი, მეორე სართულზე," იატაკს ქუსლი დაჰკრა, "ე, ზუსტად ჩემს ქვემოთ.  თანაც იმ დროს ასე იყო საჭირო, აფხაზი თუ ყავდა კაცს ცოლად, არ ერჩოდნენ... ორი გოგო ყავთ, შენი დებია მაგენი, ბებია, უნდა გეიცნო და მოეფერო..."</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					"Yes, on the second floor," she stomped her heel on the floor, "Here, right under me.  And you know, at that time it was necessary; if a man had an Abkhazian wife, they wouldn't bother him... they have two girls, they're your sisters, honey, you should meet them, and be nice to them..."</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					283</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					283</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					კონსერვი გავხსენი, ხალვა და პური დავჭერი და ამასობაში კვერცხებიც მოიხარშა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I opened the tin, cut the halva and bread, and meanwhile, the eggs boiled...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ის ღამე იქ გავათენე.  დილით ადრე ავდექი და წამოვედი, ბევრი მეხვეწა საწყალი დედაბერი, დარჩი, დარჩიო, მაგრამ არ დავუჯერე...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I spent the night there.  In the morning I got up early and left, the poor old woman begged me many times, "stay, please stay," but I didn't heed her words...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ოჩამჩირემდე ვიღაც მადლიანმა კაცმა ჩამიყვანა ძველი "მოსკვიჩით," იქიდან ენგურის ხიდამდე ავტობუსით ვიმგზავრე, მერე ზუგდიდამდე ისევ ავტობუსით და ბოლოს, მატარებლით -- თბილისამდე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					A kind man took me to Ochamchire with his old "Moskvich," from there I traveled to the Enguri bridge by bus, then to Zugdidi, again by bus, and finally, by train -- to Tbilisi.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მატარებელში არ დამეძინა, ათას რამეზე ვფიქრობდი, ვიგონებდი გალელ დედაბერს, რომელმაც იქითობისას ენგურის ხიდზე გადამიყვანა, მის დისშვილ გივის -- მარშრუტკის შოფერს, ზიტას და დაურს, მარო ბებიას...გამახსენდა ისიც, რომ მაროსთან ჩვენი კედლის საათი ვნახე და როცა ვიცანი, დედაბერმა ძალიან დაირცხვინა, თავს იმართლებდა, მამშენმა მაჩუქაო, მაგრამ მივხვდი, რომ მამაჩემს დარჩა, ამან კი წაიღო.  საათი არ მუშაობდა, გაჩერებული ეკიდა კედელზე.  მახსოვდა, რომ წინათ, იქიდან პატარა, სასაცილო ფრინველი გამოხტებოდა ხოლმე და იძახდა: "გუ-გუ!  გუ-გუ!"</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I didn't sleep on the train, I was thinking about a thousand things, I remembered the old woman from Gali, who got me across the Enguri Bridge, her nephew, Givi -- the chauffeur of the minibus, Zita and Dauri, Granny Maro... I also remembered that at Maro's place I saw our wall clock, and when I recognized it the old woman got very embarrassed, tried to justify herself by saying that my father had given it to her as a present, but I knew that my father had left it, and she had taken it.  The clock wasn't working; it hung, stopped, on the wall.  I remembered that earlier, a small, funny bird would jump out from it and cry out:  "Coo-coo!  Coo-coo!"</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					წამოსვლისას დედაბერმა საათი კედლიდან ჩამოხსნა და თან მატანდა, მაგრამ თავი მოვიკალი და არ წამოვიღე, რად მინდოდა, სად უნდა მეთრია, გაფუჭებული იყო, თუმცა, დედაჩემისთვის რომ ჩამომეტანა, იქნებ გახარებოდა კიდეც, მაგრამ არა უშავს, დედაჩემს თავისი ნიშნობის ბეჭედს მივუტან და მივუგდებ, თავიანთ საქმეს თვითონ მიხედონ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					When I was leaving, the old woman took the clock down from the wall and wanted me to take it with me, but I refused, and didn't take it. Why would I want it, where would I take it, it was broken; though, if I took it to my mother, maybe she'd even be happy, but it's ok, I'll take my mother her engagement ring, and throw it at her; they should take care of their own business themselves...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					დილით, თბილისის სადგურზე მატარებლიდან რომ ჩამოვედი, პირდაპირ ბაზრობაზე წავედი.  ფული კიდე მქონდა და ვიყიდე შავი ფერის ორი, ოცკაპიკიანი პარკი, ექვსი ცალი წებო და ჩემს სარდაფს მივაშურე.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					In the morning, when I got out of the train at the Tbilisi station, I went straight to the big market.  I still had some money, and I bought two twenty kopek black plastic bags, six tubes of glue, and went to my cellar.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მინდოდა გერასიმესთვის მკლავი მიმეკერებინა, მაგრამ აღარაფრის თავი აღარ მქონდა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I wanted to sew Gerasime's arm back on, but I wasn't able to do anything...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					284</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					284</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					იმ ღამით უამრავი ცხოველი მოვიდა...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					That night so many animals came...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მოვიდნენ სპილოები, მარტორქები, ჟირაფები, ზებრები, კამეჩები, ლომები, ანტილოპები...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Elephants, rhinoceroses, giraffes, zebras, water buffalos, lions, antelopes...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მოდიოდნენ და მოდიოდნენ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					They kept on coming and coming...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					მე ვიდექი მაღალ, ხმელ ბალახში და მესმოდა მათი ცხელი სუნთქვა, ვგრძნობდი მათ სუნს...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					I stood in the tall, dry grass and could hear their hot breath, I could sense their smell...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					ვხედავდი იქვე, ჩემს ფეხებთან ჩაწოლილ ლომებს, რომლებიც ყვითელი თვალებით მისჩერებოდნენ შორს, მინდვრის ბოლოსკენ მიმავალ ანტილოპებს...ერთი მათგანი წეღან დაეჭირათ და ახლა იმისი სისხლით მოთხვრილ დრუნჩებს ენით ილოკავდნენ.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					There at my feet, I saw lions lying down, lions staring into the distance with their yellow eyes at the antelopes moving towards the end of the field... they had caught one of them earlier, and now they were licking their chops, smeared with blood.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					საბრალო ანტილოპის ძვლებს უკვე დიდი, ყელტიტველა სვავები ძიძგნიდნენ...</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					Large vultures, with naked necks, were already picking at the bones of the poor antelope...</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					სულ ბოლოს ორი გიენაც მოვიდა.</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					And last of all, two hyenas were coming towards me.</p>
				</div>
			</div>
            <div class = "row">
				<div class="col-lg-4 georgian col-lg-offset-2">
					<p>
					285</p>
				</div>
				<div class="col-lg-4 english">
					<p>
					285</p>
				</div>
			</div>
		<?php
	bottom();
?>